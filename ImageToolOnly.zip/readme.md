# Inject MRPU

![deobf](image/claude_code_deobf.png "deobf_1")
![deobf](image/killphantomshield.png "deobf-2")
![deobf](image/zbx1425_deobf.png "deobf_3")
![deobf](image/zkm_deobf.png "deobf-4")
![deobf](image/zkm_Tab5aOff_Heavy_duty_protection.png "deobf_5")
![deobf](image/zkm_Tab5cOn_Overview.png "deobf_6")

# zh-cn
## 细节

输入至MRPU. 支持
 - 加密资源导出
 - 禁用设备封禁

### 使用

Minecraft 1.20.4 with Fabric
放置在 .Minecraft/mods 目录

# en-us

Inject by MRPU. Supports
 - Encrypt asset export
 - Disable device banned

### Use?

Minecraft 1.20.4 with Fabric
Place to .Minecraft/mods directory


