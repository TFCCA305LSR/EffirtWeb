package cd.cc.effirt.InjectMPRU.mixin;

import cd.cc.effirt.API.Network;
import cd.cc.effirt.InjectMPRU.Exception.InjectMPRUException;
import cn.zbx1425.resourcepackupdater.e;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import cd.cc.effirt.API.Log;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resource.DirectoryResourcePack;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

@Mixin(DirectoryResourcePack.class)
public class DirectoryResourcePackMixin {

    @Final
    @Shadow
    private Path root;

    @WrapMethod(method = "open(Lnet/minecraft/resource/ResourceType;Lnet/minecraft/util/Identifier;)Lnet/minecraft/resource/InputSupplier;")
    private InputSupplier<InputStream> wrapOpen(ResourceType type, Identifier id, Operation<InputSupplier<InputStream>> original) {

        InputSupplier<InputStream> supplier = original.call(type, id);
        if (supplier == null) return null;


        try {
            Path canonicalRoot = root.toRealPath();
            if (!canonicalRoot.equals(e.d.f.a)) {
                return supplier;
            }
        } catch (Exception e) {
            Log.warn("输入 Inject MPRU ", "Resolve root path failed", e);
            return supplier;
        }

        String relativePath = type.getDirectory() + "/" + id.getNamespace() + "/" + id.getPath();
        Path outputDir = FabricLoader.getInstance().getGameDir().resolve("log/output");
        Path outputFile = outputDir.resolve(relativePath);

        return () -> {
            try (InputStream in = supplier.get()) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                in.transferTo(baos);
                byte[] data = baos.toByteArray();

                Files.createDirectories(outputFile.getParent());
                Files.write(outputFile, data);
                String assetByteUnit = Network.formatByteUnit(data.length, "Byte", "KiB", "MiB", "GiB", "TiB");
                double assetByte = Network.formatByte(data.length);
                Log.info("输入 Inject MPRU", "Injecting: %s(%s %s)", outputFile, assetByte, assetByteUnit);

                return new ByteArrayInputStream(data);
            } catch (Exception e) {
                Log.error("输入 Inject MPRU","Inject failed: " + relativePath,e);
                throw new InjectMPRUException("Inject failed: " + relativePath, e);
            }
        };
    }
}