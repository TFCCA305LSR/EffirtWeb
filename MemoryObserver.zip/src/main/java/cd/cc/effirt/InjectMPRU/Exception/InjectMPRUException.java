package cd.cc.effirt.InjectMPRU.Exception;

public class InjectMPRUException extends RuntimeException {
    public InjectMPRUException(String message, Throwable cause) {
        super(message, cause);
    }
}
