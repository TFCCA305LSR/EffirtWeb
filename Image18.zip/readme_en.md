# Inject MRPU

![deobf](image/claude_code_deobf.png "deobf_1")
![deobf](image/killphantomshield.png "deobf-2")
![deobf](image/zbx1425_deobf.png "deobf_3")
![deobf](image/zkm_deobf.png "deobf-4")
![deobf](image/zkm_Tab5aOff_Heavy_duty_protection.png "deobf_5")
![deobf](image/zkm_Tab5cOn_Overview.png "deobf_6")

## The problem with MTR Resource Pack Update
1. The downloaded resource is encrypted
2. When one account gets banned, another account can't enter the server.

## Inject MRPU fixed for MTR Resource Pack Update
1. The downloaded resources are encrypted -> Now the unencrypted resources will be exported to ".minecraft/log/output". Can be edited in Adobe Photoshop.
2. When one account was banned, another account couldn't access the server -> Now it can access the server without any problem

## MTR Resource Pack Update Details

After a 7-second analysis with Opus 4.7, MTR Resource Pack Update used high-intensity ProGuard for obfuscation //obf Strong--

Using Opus 4.7, the MTR Resource Pack Update source code will directly resume after UTC/GMT 08:00 + 3 second.

## Build

Build using Java >= 17. Final "Image18.jar" at "build/libs"
```
./gradlew build
```