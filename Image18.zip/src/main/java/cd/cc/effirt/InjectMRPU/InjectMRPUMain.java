
package cd.cc.effirt.InjectMRPU;

import cd.cc.effirt.API.Log;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InjectMRPUMain implements ModInitializer, PreLaunchEntrypoint {

    public static final String MOD_ID = "InjectMRPU";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        String info = """
                
                $$$$$$\\                                     $$\\           $$\\      $$\\ $$$$$$$\\  $$$$$$$\\  $$\\   $$\\\s
                \\_$$  _|                                    $$ |          $$$\\    $$$ |$$  __$$\\ $$  __$$\\ $$ |  $$ |
                  $$ |  $$$$$$$\\  $$\\  $$$$$$\\   $$$$$$$\\ $$$$$$\\         $$$$\\  $$$$ |$$ |  $$ |$$ |  $$ |$$ |  $$ |
                  $$ |  $$  __$$\\ \\__|$$  __$$\\ $$  _____|\\_$$  _|        $$\\$$\\$$ $$ |$$$$$$$  |$$$$$$$  |$$ |  $$ |
                  $$ |  $$ |  $$ |$$\\ $$$$$$$$ |$$ /        $$ |          $$ \\$$$  $$ |$$  __$$< $$  ____/ $$ |  $$ |
                  $$ |  $$ |  $$ |$$ |$$   ____|$$ |        $$ |$$\\       $$ |\\$  /$$ |$$ |  $$ |$$ |      $$ |  $$ |
                $$$$$$\\ $$ |  $$ |$$ |\\$$$$$$$\\ \\$$$$$$$\\   \\$$$$  |      $$ | \\_/ $$ |$$ |  $$ |$$ |      \\$$$$$$  |
                \\______|\\__|  \\__|$$ | \\_______| \\_______|   \\____/       \\__|     \\__|\\__|  \\__|\\__|       \\______/\s
                            $$\\   $$ |                                                                              \s
                            \\$$$$$$  |                                                                              \s
                             \\______/                                                                               \s
                             (Inject MRPU) By Effirt
                """;
        Log.info("输入 Inject MRPU",info);
        Log.info("输入 Inject MRPU", "开始中. 热输入 Starting Inject MRPU");
        LOGGER.info("Initializing: Image18");
    }

    @Override
    public void onPreLaunch() {
    }
}
