
package cd.cc.effirt.InjectMRPU;

import cd.cc.effirt.API.Log;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InjectMRPUMain implements ModInitializer, PreLaunchEntrypoint {

    public static final String MOD_ID = "InjectMRPU";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        String info = """
                \033[38;2;181;181;239m
                  ___        _           _     __  __ ____  ____  _   _
                 |_ _|_ __  (_) ___  ___| |_  |  \\/  |  _ \\|  _ \\| | | |
                  | || '_ \\ | |/ _ \\/ __| __| | |\\/| | |_) | |_) | | | |
                  | || | | || |  __/ (__| |_  | |  | |  _ <|  __/| |_| |
                 |___|_| |_|/ |\\___|\\___|\\__| |_|  |_|_| \\_\\_|    \\___/
                          |__/
                ============================================================
                Inject MRPU (By Effirt)
                ============================================================\033[0m
                """;
        Log.info("输入 Inject MRPU",info);
        Log.info("输入 Inject MRPU", "开始中. 热输入 Starting Inject MRPU");
        LOGGER.info("Initializing: Image18");
    }

    @Override
    public void onPreLaunch() {
    }
}
