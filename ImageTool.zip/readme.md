# Inject MRPU

![deobf](image/claude_code_deobf.png "deobf_1")
![deobf](image/killphantomshield.png "deobf-2")
![deobf](image/zbx1425_deobf.png "deobf_3")
![deobf](image/zkm_deobf.png "deobf-4")
![deobf](image/zkm_Tab5aOff_Heavy_duty_protection.png "deobf_5")
![deobf](image/zkm_Tab5cOn_Overview.png "deobf_6")

## MRPU的问题
 1. 下载的资源是加密的
 2. 当一个账号被封禁后另一个账号无法进入服务器

## Inject MRPU 修复了
 1. 下载的资源是加密的 -> 现在会将未加密资源导出至.minecraft/log/output
 2. 当一个账号被封禁后另一个账号无法进入服务器 -> 现在不再会无法进入服务器

## MRPU细节

使用claude code 进行分析, 经过claude code长达7秒的分析, MRPU使用了高强度的ProGuard进行混淆(String obfuscate? Control flow obfuscate?)

## 构建

使用Java >= 17进行构建
```
./gradlew build
```

>
# 免责声明
如果你使用Inject MRPU时出现任何事情, 均和本项目和作者无关