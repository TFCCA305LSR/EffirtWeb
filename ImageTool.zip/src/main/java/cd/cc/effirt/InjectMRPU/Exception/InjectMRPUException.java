package cd.cc.effirt.InjectMRPU.Exception;

public class InjectMRPUException extends RuntimeException {
    public InjectMRPUException(String message, Throwable cause) {
        super(message, cause);
    }
}
