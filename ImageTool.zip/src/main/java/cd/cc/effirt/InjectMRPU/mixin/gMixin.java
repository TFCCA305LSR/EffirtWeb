package cd.cc.effirt.InjectMRPU.mixin;

import cn.zbx1425.resourcepackupdater.g;
import net.minecraft.server.network.ServerConfigurationNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(g.class)
public abstract class gMixin {

    @Inject(
            method = "a(Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/server/network/ServerConfigurationNetworkHandler;)Z",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void disableDeviceBan(String var0, String var1, ServerConfigurationNetworkHandler var2, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }
}