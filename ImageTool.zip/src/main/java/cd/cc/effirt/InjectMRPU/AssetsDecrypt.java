
package cd.cc.effirt.InjectMRPU;

import cd.cc.effirt.API.Log;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AssetsDecrypt implements ModInitializer, PreLaunchEntrypoint {

	public static final String MOD_ID = "AssetsDecrypt";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		Log.info("输入 Inject MRPU","开始中. 热输入 Starting Inject MRPU");
		//LOGGER.info("Hello Effirt World in onInitialize");
	}
	@Override
	public void onPreLaunch() {
		//LOGGER.info("Hello Effirt World in onPreLaunch");
	}
}
