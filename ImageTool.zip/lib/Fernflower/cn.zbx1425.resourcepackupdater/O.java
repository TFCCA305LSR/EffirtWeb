package cn.zbx1425.resourcepackupdater;

public class O {
   public static final int a = 8;

   public static Object a(String var0, Q var1, P var2) {
      int var3 = 0;

      while(true) {
         try {
            Object var4 = var1.run();
            if (var3 > 0) {
               var2.log(String.format("Fetching %s ... (Retry %d succeed)", var0, var3));
            }

            return var4;
         } catch (Exception var5) {
            ++var3;
            if (var3 >= 8) {
               var2.log(String.format("Fetching of %s ultimately failed after %d attempts:", var0, var3));
               var2.log(var5.toString());
               throw var5;
            }

            var2.log(String.format("Retry (%d/%d) for %s due to error:", var3, 7, var0));
            var2.log(String.format("Retry %d: %s", var3, var5.toString()));
         }
      }
   }
}
