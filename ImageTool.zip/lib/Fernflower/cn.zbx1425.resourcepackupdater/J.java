package cn.zbx1425.resourcepackupdater;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class J {
   private final F e;
   public long a;
   private long f;
   private long g = -1L;
   private long h = 0L;
   private long i = 0L;
   public long b = 0L;
   private final ExecutorService j = Executors.newFixedThreadPool(4);
   public ConcurrentLinkedQueue c = new ConcurrentLinkedQueue();
   public ConcurrentLinkedQueue d = new ConcurrentLinkedQueue();
   private final ConcurrentLinkedQueue k = new ConcurrentLinkedQueue();
   private Exception l = null;
   private static final int m = 8;

   public J(F var1) {
      this.e = var1;
   }

   public void a(K var1) {
      this.a += var1.c;
      this.d.add(var1);
      this.j.submit(() -> {
         this.c.add(var1);

         try {
            while(true) {
               try {
                  var1.a();
                  synchronized(this) {
                     this.f += var1.c;
                     this.i += var1.b;
                  }

                  if (var1.f > 0) {
                     this.k.add((Runnable)() -> this.e.a(String.format("Downloading files ... (Retry %d succeed)", var1.f)));
                  }
                  break;
               } catch (Exception var10) {
                  ++var1.f;
                  if (var1.f >= 8) {
                     this.k.add((Runnable)() -> {
                        this.e.a(String.format("Download of %s ultimately failed after %d attempts:", var1.e, var1.f));
                        this.e.a(var10.toString());
                     });
                     throw var10;
                  }

                  this.k.add((Runnable)() -> {
                     this.e.a(String.format("Retry (%d/%d) for %s due to error:", var1.f, 7, var1.e));
                     this.e.a(String.format("Retry %d: %s", var1.f, var10.toString()));
                  });
               }
            }
         } catch (Exception var11) {
            this.l = var11;
            this.j.shutdown();
            this.c.clear();
            this.d.clear();
         } finally {
            this.c.remove(var1);
            this.d.remove(var1);
         }

      });
   }

   protected void a() {
   }

   public void b() {
      while(!this.k.isEmpty()) {
         ((Runnable)this.k.poll()).run();
      }

      float var1 = this.f();
      long var2;
      synchronized(this) {
         var2 = this.i;

         for(K var6 : this.c) {
            var2 += var6.b;
         }
      }

      if (this.g == -1L) {
         this.g = System.currentTimeMillis();
         this.h = var2;
      } else {
         long var4 = System.currentTimeMillis();
         long var15 = var4 - this.g;
         if (var15 > 0L) {
            double var8 = 0.05;
            double var10 = (double)(var2 - this.h) * (double)1000.0F / (double)var15;
            this.b = (long)((double)this.b * ((double)1.0F - var8) + var10 * var8);
            this.g = var4;
            this.h = var2;
         }
      }

      String var13 = String.format(": %5d KiB/s", this.b / 1024L);
      this.e.a(var1);
      int var10000 = this.d.size();
      String var14 = var10000 + " Files Remaining\n" + String.join("\n", this.c.stream().map((var0) -> {
         String var10000 = var0.a == 0L ? "WAIT" : String.format("%.1f%%", var0.b() * 100.0F);
         return "  " + var10000 + "\t" + (var0.f > 0 ? "(RETRY " + var0.f + ") " : "") + var0.e;
      }).toList());
      this.e.a(var14, var13);
   }

   private float f() {
      if (this.a <= 0L) {
         return 0.0F;
      } else {
         float var1 = 0.0F;

         for(K var3 : this.c) {
            var1 += (float)var3.c * var3.b();
         }

         return ((float)this.f + var1) / (float)this.a;
      }
   }

   public long c() {
      synchronized(this) {
         long var1 = this.i;

         for(K var5 : this.c) {
            var1 += var5.b;
         }

         return var1;
      }
   }

   public boolean d() {
      if (this.l == null) {
         return this.d.isEmpty();
      } else {
         while(!this.k.isEmpty()) {
            ((Runnable)this.k.poll()).run();
         }

         throw this.l;
      }
   }

   public void e() {
      this.j.shutdown();
   }
}
