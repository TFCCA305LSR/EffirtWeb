package cn.zbx1425.resourcepackupdater;

import net.minecraft.class_2561;
import net.minecraft.class_5250;

public interface R {
   static class_5250 a(String var0, Object... var1) {
      return class_2561.method_43469(var0, var1);
   }

   static class_5250 a(String var0) {
      return class_2561.method_43470(var0);
   }
}
