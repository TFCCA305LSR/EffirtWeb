package cn.zbx1425.resourcepackupdater;

class L implements N {
   final long a;
   long b;
   // $FF: synthetic field
   final K c;

   L(K var1) {
      this.c = var1;
      this.a = 8192L;
      this.b = 0L;
   }

   public void a(long var1) {
      if (this.b / 8192L != var1 / 8192L) {
         this.c.b = var1;
         this.c.d.a();
         this.b = var1;
      }

   }
}
