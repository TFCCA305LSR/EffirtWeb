package cn.zbx1425.resourcepackupdater;

import com.github.luben.zstd.Zstd;
import com.github.luben.zstd.ZstdInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class n {
   private static final long a = 3776222123544158591L;
   private static final long b = -5742101624168495731L;
   private static final long c = -2619596096539158457L;
   private static final long d = -7665143305294351052L;

   public static byte[] a(UUID var0) {
      long var1 = var0.getMostSignificantBits() ^ 3776222123544158591L;
      long var3 = var0.getLeastSignificantBits() ^ -5742101624168495731L;
      return a(var1, var3);
   }

   public static byte[] a(UUID var0, long var1) {
      long var3 = var0.getMostSignificantBits() ^ var1 ^ -2619596096539158457L;
      long var5 = var0.getLeastSignificantBits() ^ var1 ^ -7665143305294351052L;
      return a(var3, var5);
   }

   public static InputStream a(InputStream var0, byte[] var1, byte[] var2) {
      InputStream var3 = b(var0, var1, var2);
      return new ZstdInputStream(var3);
   }

   public static byte[] a(byte[] var0, byte[] var1, byte[] var2) {
      byte[] var3 = c(var0, var1, var2);
      ZstdInputStream var4 = new ZstdInputStream(new ByteArrayInputStream(var3));

      byte[] var6;
      try {
         ByteArrayOutputStream var5 = new ByteArrayOutputStream();

         try {
            var4.transferTo(var5);
            var6 = var5.toByteArray();
         } catch (Throwable var10) {
            try {
               var5.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }

            throw var10;
         }

         var5.close();
      } catch (Throwable var11) {
         try {
            var4.close();
         } catch (Throwable var8) {
            var11.addSuppressed(var8);
         }

         throw var11;
      }

      var4.close();
      return var6;
   }

   public static byte[] b(byte[] var0, byte[] var1, byte[] var2) {
      byte[] var3 = Zstd.compress(var0);
      return d(var3, var1, var2);
   }

   public static InputStream b(InputStream var0, byte[] var1, byte[] var2) {
      try {
         Cipher var3 = Cipher.getInstance("AES/CTR/NoPadding");
         var3.init(2, new SecretKeySpec(var1, "AES"), new IvParameterSpec(var2));
         return new CipherInputStream(var0, var3);
      } catch (GeneralSecurityException var4) {
         throw new IOException("AES decryption init failed", var4);
      }
   }

   public static byte[] c(byte[] var0, byte[] var1, byte[] var2) {
      try {
         Cipher var3 = Cipher.getInstance("AES/CTR/NoPadding");
         var3.init(2, new SecretKeySpec(var1, "AES"), new IvParameterSpec(var2));
         return var3.doFinal(var0);
      } catch (GeneralSecurityException var4) {
         throw new IOException("AES decryption failed", var4);
      }
   }

   public static byte[] d(byte[] var0, byte[] var1, byte[] var2) {
      try {
         Cipher var3 = Cipher.getInstance("AES/CTR/NoPadding");
         var3.init(1, new SecretKeySpec(var1, "AES"), new IvParameterSpec(var2));
         return var3.doFinal(var0);
      } catch (GeneralSecurityException var4) {
         throw new IOException("AES encryption failed", var4);
      }
   }

   private static byte[] a(long var0, long var2) {
      ByteBuffer var4 = ByteBuffer.allocate(16);
      var4.putLong(var0);
      var4.putLong(var2);
      return var4.array();
   }
}
