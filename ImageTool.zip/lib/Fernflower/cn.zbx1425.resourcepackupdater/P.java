package cn.zbx1425.resourcepackupdater;

public interface P {
   void log(String var1);
}
