package cn.zbx1425.resourcepackupdater;

import java.io.InputStream;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_3298;

public class x extends class_3298 {
   public x(class_2960 var1) {
      super(new y(), () -> {
         String var10001 = var1.method_12836();
         return (InputStream)Objects.requireNonNull(x.class.getResourceAsStream("/assets/" + var10001 + "/" + var1.method_12832()));
      });
   }
}
