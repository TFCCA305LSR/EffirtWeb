//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package cn.zbx1425.resourcepackupdater.mixin;

import cn.zbx1425.resourcepackupdater.G;
import cn.zbx1425.resourcepackupdater.I;
import cn.zbx1425.resourcepackupdater.e;
import cn.zbx1425.resourcepackupdater.n;
import cn.zbx1425.resourcepackupdater.o;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_3255;
import net.minecraft.class_3259;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3797;
import net.minecraft.class_7367;
import org.apache.commons.io.IOUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_3259.class})
public abstract class FolderPackResourcesMixin extends class_3255 {
    @Unique
    private Path canonicalRoot;
    @Shadow
    @Final
    private Path field_40001;

    @Unique
    private Path getCanonicalRoot() {
        if (this.canonicalRoot == null) {
            try {
                this.canonicalRoot = this.field_40001.toRealPath();
            } catch (IOException var2) {
                this.canonicalRoot = this.field_40001;
            }
        }

        return this.canonicalRoot;
    }

    @Unique
    private boolean isSyncedPack() {
        return this.getCanonicalRoot().equals(e.d.f.a);
    }

    private FolderPackResourcesMixin(String var1, boolean var2) {
        super(var1, var2);
    }

    @Inject(
        method = {"getRootResource"},
        at = {@At("HEAD")},
        cancellable = true
    )
    public void getRootResource(String[] var1, CallbackInfoReturnable<class_7367<InputStream>> var2) {
        if (this.isSyncedPack()) {
            Path var3 = this.field_40001.normalize();
            Path var4 = var3.resolve(String.join("/", var1)).normalize();
            if (!var4.startsWith(var3)) {
                var2.setReturnValue((Object)null);
            } else {
                if (Files.exists(var4, new LinkOption[0])) {
                    if (Arrays.equals(var1, new String[]{"pack.mcmeta"})) {
                        var2.setReturnValue((class_7367)() -> patchPackMeta(new BufferedInputStream(Files.newInputStream(var4))));
                    } else {
                        var2.setReturnValue((class_7367)() -> new BufferedInputStream(Files.newInputStream(var4)));
                    }
                } else {
                    var2.setReturnValue((Object)null);
                }

            }
        }
    }

    @Inject(
        method = {"getResource(Lnet/minecraft/server/packs/PackType;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/server/packs/resources/IoSupplier;"},
        at = {@At("HEAD")},
        cancellable = true
    )
    void getResource(class_3264 var1, class_2960 var2, CallbackInfoReturnable<class_7367<InputStream>> var3) {
        if (this.isSyncedPack()) {
            if (o.a()) {
                var3.setReturnValue((Object)null);
            } else {
                G var4 = e.a();
                if (var4 == null) {
                    var3.setReturnValue((Object)null);
                } else {
                    String var10000 = var1.method_14413();
                    String var5 = var10000 + "/" + var2.method_12836() + "/" + var2.method_12832();
                    I var6 = var4.a(var5);
                    if (var6 == null) {
                        var3.setReturnValue((Object)null);
                    } else {
                        var3.setReturnValue((class_7367)() -> this.openMasbinFile(var4, var6));
                    }
                }
            }
        }
    }

    @WrapMethod(
        method = {"listResources"}
    )
    void getResources(class_3264 var1, String var2, String var3, class_3262.class_7664 var4, Operation<Void> var5) {
        if (!this.isSyncedPack()) {
            var5.call(new Object[]{var1, var2, var3, var4});
        } else if (!o.a()) {
            e.b.info("Requested listResources for {}:{}", var2, var3);
            G var6 = e.a();
            if (var6 != null) {
                I var7 = var6.a();
                I var8 = var7.a(var1.method_14413());
                if (var8 != null) {
                    I var9 = var8.a(var2);
                    if (var9 != null) {
                        String[] var10 = var3.split("/");
                        I var11 = var9;

                        for(String var15 : var10) {
                            if (!var15.isEmpty()) {
                                var11 = var11.a(var15);
                                if (var11 == null) {
                                    return;
                                }
                            }
                        }

                        this.listEntriesRecursive(var6, var11, var1.method_14413() + "/" + var2 + "/" + var3, var4);
                    }
                }
            }
        }
    }

    @Inject(
        method = {"getNamespaces"},
        at = {@At("HEAD")},
        cancellable = true
    )
    void getNamespaces(class_3264 var1, CallbackInfoReturnable<Set<String>> var2) {
        if (this.isSyncedPack()) {
            if (o.a()) {
                var2.setReturnValue(Collections.emptySet());
            } else {
                G var3 = e.a();
                if (var3 == null) {
                    var2.setReturnValue(Collections.emptySet());
                } else {
                    I var4 = var3.a();
                    I var5 = var4.a(var1.method_14413());
                    if (var5 == null) {
                        var2.setReturnValue(Collections.emptySet());
                    } else {
                        HashSet var6 = new HashSet();

                        for(I var8 : var5.a()) {
                            if (var8.b) {
                                var6.add(var8.a);
                            }
                        }

                        var2.setReturnValue(var6);
                    }
                }
            }
        }
    }

    @Unique
    private void listEntriesRecursive(G var1, I var2, String var3, class_3262.class_7664 var4) {
        for(I var6 : var2.a()) {
            String var7 = var3 + "/" + var6.a;
            if (var6.b) {
                this.listEntriesRecursive(var1, var6, var7, var4);
            } else {
                String[] var8 = var7.split("/", 3);
                if (var8.length >= 3) {
                    String var9 = var8[2];
                    class_2960 var10 = new class_2960(var8[1], var9);
                    var4.accept(var10, (class_7367)() -> this.openMasbinFile(var1, var6));
                }
            }
        }

    }

    @Unique
    private InputStream openMasbinFile(G var1, I var2) {
        Path var3 = G.a(this.field_40001, var2.e);
        if (!Files.exists(var3, new LinkOption[0])) {
            throw new FileNotFoundException("masbin file not found: " + String.valueOf(var3));
        } else {
            BufferedInputStream var4 = new BufferedInputStream(Files.newInputStream(var3));
            byte[] var5 = ((InputStream)var4).readNBytes(16);
            if (var5.length < 16) {
                ((InputStream)var4).close();
                throw new IOException("masbin file too short for IV: " + String.valueOf(var3));
            } else {
                byte[] var6 = n.a(var1.b, var2.e);
                return (InputStream)(var2.a.endsWith(".ogg") ? new ByteArrayInputStream(n.a(var4, var6, var5).readAllBytes()) : n.a(var4, var6, var5));
            }
        }
    }

    @Unique
    private static InputStream patchPackMeta(InputStream var0) {
        JsonObject var1 = JsonParser.parseString(IOUtils.toString(var0, StandardCharsets.UTF_8)).getAsJsonObject();
        var1.getAsJsonObject("pack").addProperty("pack_format", class_3797.method_16672().method_48017(class_3264.field_14188));
        return IOUtils.toInputStream(var1.toString(), StandardCharsets.UTF_8);
    }
}
