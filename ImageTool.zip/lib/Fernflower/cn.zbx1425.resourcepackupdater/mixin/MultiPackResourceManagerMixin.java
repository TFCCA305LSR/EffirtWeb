//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package cn.zbx1425.resourcepackupdater.mixin;

import cn.zbx1425.resourcepackupdater.x;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_6861;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_6861.class})
public class MultiPackResourceManagerMixin {
    @Inject(
        at = {@At("HEAD")},
        method = {"getResource"},
        cancellable = true
    )
    void getResource(class_2960 var1, CallbackInfoReturnable<Optional<class_3298>> var2) {
        if (var1.method_12836().equals("resourcepackupdater")) {
            String var10000 = var1.method_12836();
            String var3 = "/assets/" + var10000 + "/" + var1.method_12832();
            if (x.class.getResource(var3) == null) {
                return;
            }

            var2.setReturnValue(Optional.of(new x(var1)));
            var2.cancel();
        }

    }
}
