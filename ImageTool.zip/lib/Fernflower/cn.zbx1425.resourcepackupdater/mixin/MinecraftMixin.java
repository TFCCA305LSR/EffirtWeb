//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package cn.zbx1425.resourcepackupdater.mixin;

import cn.zbx1425.resourcepackupdater.f;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_310.class})
public class MinecraftMixin {
    @Inject(
        at = {@At("HEAD")},
        method = {"reloadResourcePacks()Ljava/util/concurrent/CompletableFuture;"}
    )
    void reloadResourcePacks(CallbackInfoReturnable<CompletableFuture<Void>> var1) {
        f.a();
        f.b();
    }

    @Inject(
        at = {@At(
    value = "INVOKE",
    target = "Lnet/minecraft/server/packs/repository/PackRepository;openAllSelected()Ljava/util/List;"
)},
        method = {"<init>"}
    )
    void ctor(class_542 var1, CallbackInfo var2) {
        f.a();
        f.b();
    }
}
