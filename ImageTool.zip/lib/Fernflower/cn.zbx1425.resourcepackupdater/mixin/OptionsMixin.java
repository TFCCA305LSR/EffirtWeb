//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package cn.zbx1425.resourcepackupdater.mixin;

import cn.zbx1425.resourcepackupdater.f;
import net.minecraft.class_315;
import net.minecraft.class_3283;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_315.class})
public class OptionsMixin {
    @Inject(
        at = {@At(
    value = "INVOKE",
    target = "Lnet/minecraft/client/Options;save()V"
)},
        method = {"updateResourcePacks"}
    )
    void updatePackList(class_3283 var1, CallbackInfo var2) {
        f.b();
    }
}
