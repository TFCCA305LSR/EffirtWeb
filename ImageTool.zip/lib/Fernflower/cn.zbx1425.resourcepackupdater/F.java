package cn.zbx1425.resourcepackupdater;

public interface F {
   void a(String var1);

   void b(String var1);

   void a(float var1);

   void a(String var1, String var2);

   void a(Exception var1);

   default void a(String var1, Object... var2) {
      this.a(b(var1, var2));
   }

   default void a() {
   }

   static String b(String var0, Object[] var1) {
      if (var1 != null && var1.length != 0) {
         StringBuilder var2 = new StringBuilder();
         int var3 = 0;
         int var4 = 0;

         while(var4 < var0.length()) {
            if (var4 < var0.length() - 1 && var0.charAt(var4) == '{' && var0.charAt(var4 + 1) == '}') {
               if (var3 < var1.length) {
                  var2.append(var1[var3++]);
               } else {
                  var2.append("{}");
               }

               var4 += 2;
            } else {
               var2.append(var0.charAt(var4));
               ++var4;
            }
         }

         return var2.toString();
      } else {
         return var0;
      }
   }
}
