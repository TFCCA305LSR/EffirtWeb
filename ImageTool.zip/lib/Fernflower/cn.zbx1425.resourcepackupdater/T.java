package cn.zbx1425.resourcepackupdater;

import net.fabricmc.fabric.api.networking.v1.FabricPacket;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class T implements FabricPacket {
   public static final PacketType a = PacketType.create(new class_2960("zbx_rpu", "server_lock"), T::new);
   public final String b;

   public T(String var1) {
      this.b = var1;
   }

   public T(class_2540 var1) {
      this.b = var1.method_19772();
   }

   public void write(class_2540 var1) {
      var1.method_10814(this.b);
   }

   public PacketType getType() {
      return a;
   }
}
