package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.function.Function;
import java.util.function.Supplier;

public class b {
   public Object a;
   public boolean b;
   private boolean c;
   private final String d;
   private final Function e;
   private final Function f;
   private final Supplier g;

   public b(String var1, Function var2, Function var3, Object var4) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
      this.g = () -> var4;
      this.a = this.g.get();
   }

   public b(String var1, Function var2, Function var3, Supplier var4) {
      this.d = var1;
      this.e = var2;
      this.f = var3;
      this.g = var4;
      this.a = var4.get();
   }

   public void a(JsonObject var1, JsonObject var2) {
      if (var1.has("!" + this.d)) {
         this.a = this.e.apply(var1.get("!" + this.d));
         this.b = true;
         this.c = true;
      } else if (var2.has(this.d)) {
         this.a = this.e.apply(var2.get(this.d));
         this.b = false;
      } else if (var1.has(this.d)) {
         this.a = this.e.apply(var1.get(this.d));
         this.b = true;
      } else {
         this.a = this.g.get();
         this.b = false;
      }

   }

   public void a(JsonObject var1) {
      if (this.b && this.a != null) {
         var1.add((this.c ? "!" : "") + this.d, (JsonElement)this.f.apply(this.a));
      }

   }
}
