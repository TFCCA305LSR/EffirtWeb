package cn.zbx1425.resourcepackupdater;

public interface N {
   void a(long var1);
}
