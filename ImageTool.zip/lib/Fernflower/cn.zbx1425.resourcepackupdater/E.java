package cn.zbx1425.resourcepackupdater;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.LongSets;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

public class E {
   private final Path a;
   private final LongOpenHashSet b = new LongOpenHashSet();
   private final Set c = new HashSet();

   public E(Path var1) {
      this.a = var1;
   }

   public LongSet a() {
      return LongSets.unmodifiable(this.b);
   }

   public Set b() {
      return Collections.unmodifiableSet(this.c);
   }

   public void a(G var1, F var2) {
      Files.createDirectories(this.a);
      this.b(var1, var2);
      this.c(var1, var2);
   }

   private void b(G var1, F var2) {
      Path var3 = this.a.resolve("masbin");
      if (Files.isDirectory(var3, new LinkOption[0])) {
         Map var4 = var1.b();
         Long2ObjectOpenHashMap var5 = new Long2ObjectOpenHashMap();

         for(Map.Entry var7 : var4.entrySet()) {
            if (!var1.b((String)var7.getKey())) {
               var5.put(((I)var7.getValue()).e, (I)var7.getValue());
            }
         }

         int var31 = 0;
         int var32 = 0;
         Stream var8 = Files.list(var3);

         try {
            for(Path var10 : var8.toList()) {
               if (Files.isDirectory(var10, new LinkOption[0])) {
                  Stream var11 = Files.list(var10);

                  try {
                     var32 += (int)var11.count();
                  } catch (Throwable var26) {
                     if (var11 != null) {
                        try {
                           var11.close();
                        } catch (Throwable var25) {
                           var26.addSuppressed(var25);
                        }
                     }

                     throw var26;
                  }

                  if (var11 != null) {
                     var11.close();
                  }
               }
            }
         } catch (Throwable var30) {
            if (var8 != null) {
               try {
                  var8.close();
               } catch (Throwable var24) {
                  var30.addSuppressed(var24);
               }
            }

            throw var30;
         }

         if (var8 != null) {
            var8.close();
         }

         var8 = Files.list(var3);

         try {
            for(Path var35 : var8.toList()) {
               if (Files.isDirectory(var35, new LinkOption[0])) {
                  Stream var36 = Files.list(var35);

                  try {
                     for(Path var13 : var36.toList()) {
                        if (Files.isRegularFile(var13, new LinkOption[0])) {
                           String var14 = var13.getFileName().toString();
                           if (var14.endsWith(".tmp")) {
                              Files.deleteIfExists(var13);
                           } else if (var14.endsWith(".bin")) {
                              ++var31;
                              if (var31 % 100 == 0) {
                                 var2.a(var32 > 0 ? (float)var31 / (float)var32 : 0.0F);
                                 var2.a(var31 + " / " + var32, "");
                              }

                              long var15;
                              try {
                                 var15 = a(var14);
                              } catch (NumberFormatException var27) {
                                 continue;
                              }

                              if (String.format("%02x", (int)(var15 & 255L)).equals(var35.getFileName().toString())) {
                                 I var17 = (I)var5.get(var15);
                                 if (var17 != null) {
                                    long var18 = Files.getLastModifiedTime(var13).toMillis();
                                    long var20 = G.b(var17.d);
                                    if (Math.abs(var18 - var20) < 2000L) {
                                       this.b.add(var15);
                                    } else if (this.a(var13, var1.b, var15)) {
                                       this.b.add(var15);
                                       Files.setLastModifiedTime(var13, FileTime.fromMillis(var20));
                                    }
                                 }
                              }
                           }
                        }
                     }
                  } catch (Throwable var28) {
                     if (var36 != null) {
                        try {
                           var36.close();
                        } catch (Throwable var23) {
                           var28.addSuppressed(var23);
                        }
                     }

                     throw var28;
                  }

                  if (var36 != null) {
                     var36.close();
                  }
               }
            }
         } catch (Throwable var29) {
            if (var8 != null) {
               try {
                  var8.close();
               } catch (Throwable var22) {
                  var29.addSuppressed(var22);
               }
            }

            throw var29;
         }

         if (var8 != null) {
            var8.close();
         }

      }
   }

   private void c(G var1, F var2) {
      for(String var4 : var1.c()) {
         Path var5 = this.a.resolve(var4);
         if (Files.isRegularFile(var5, new LinkOption[0])) {
            I var6 = var1.a(var4);
            if (var6 != null) {
               long var7 = Files.getLastModifiedTime(var5).toMillis();
               long var9 = G.b(var6.d);
               if (Math.abs(var7 - var9) < 2000L) {
                  this.c.add(var4);
               } else {
                  BufferedInputStream var11 = new BufferedInputStream(Files.newInputStream(var5));

                  try {
                     long var12 = G.a((InputStream)var11);
                     if (var12 == var6.e) {
                        this.c.add(var4);
                        Files.setLastModifiedTime(var5, FileTime.fromMillis(var9));
                     }
                  } catch (Throwable var15) {
                     try {
                        ((InputStream)var11).close();
                     } catch (Throwable var14) {
                        var15.addSuppressed(var14);
                     }

                     throw var15;
                  }

                  ((InputStream)var11).close();
               }
            }
         }
      }

   }

   private boolean a(Path var1, UUID var2, long var3) {
      try {
         BufferedInputStream var5 = new BufferedInputStream(Files.newInputStream(var1));

         boolean var17;
         label61: {
            boolean var11;
            try {
               byte[] var6 = ((InputStream)var5).readNBytes(16);
               if (var6.length < 16) {
                  var17 = false;
                  break label61;
               }

               byte[] var7 = n.a(var2, var3);
               InputStream var8 = n.a((InputStream)var5, var7, var6);

               try {
                  long var9 = G.a(var8);
                  var11 = var9 == var3;
               } catch (Throwable var14) {
                  if (var8 != null) {
                     try {
                        var8.close();
                     } catch (Throwable var13) {
                        var14.addSuppressed(var13);
                     }
                  }

                  throw var14;
               }

               if (var8 != null) {
                  var8.close();
               }
            } catch (Throwable var15) {
               try {
                  ((InputStream)var5).close();
               } catch (Throwable var12) {
                  var15.addSuppressed(var12);
               }

               throw var15;
            }

            ((InputStream)var5).close();
            return var11;
         }

         ((InputStream)var5).close();
         return var17;
      } catch (Exception var16) {
         return false;
      }
   }

   private static long a(String var0) {
      String var1 = var0.substring(0, var0.length() - 4);
      return Long.parseUnsignedLong(var1, 16);
   }
}
