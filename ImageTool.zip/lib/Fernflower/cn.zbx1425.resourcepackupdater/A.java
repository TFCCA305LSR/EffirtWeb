package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonObject;

public class A {
   public final float a;
   public final float b;
   public final float c;
   public final float d;
   public final float e;
   public final float f;
   public final float g;
   public final float h;
   public final float i;

   public A(JsonObject var1, z var2) {
      this.a = (float)var1.get("x").getAsInt() * 1.0F / var2.b;
      this.b = (float)var1.get("y").getAsInt() * 1.0F / var2.c;
      this.c = this.a + (float)var1.get("width").getAsInt() * 1.0F / var2.b;
      this.d = this.b + (float)var1.get("height").getAsInt() * 1.0F / var2.c;
      this.e = (float)var1.get("width").getAsInt() * 1.0F / var2.a;
      this.f = (float)var1.get("height").getAsInt() * 1.0F / var2.a;
      this.i = (float)var1.get("advance").getAsInt() * 1.0F / var2.a;
      this.g = (float)(-var1.get("originX").getAsInt()) * 1.0F / var2.a;
      this.h = (float)(-var1.get("originY").getAsInt()) * 1.0F / var2.a;
   }
}
