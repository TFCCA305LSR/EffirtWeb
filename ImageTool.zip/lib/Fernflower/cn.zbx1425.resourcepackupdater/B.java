package cn.zbx1425.resourcepackupdater;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;

public class B {
   private static final String a = "masmeta.bin";
   private G b;

   public G a() {
      return this.b;
   }

   public boolean a(Path var1, String var2, F var3) {
      try {
         if (var2.isEmpty()) {
            throw new IOException("There is no source configured. Install the config file to your config folder!");
         } else {
            var3.a("MRPU v{} (C) Zbx1425, www.zbx1425.cn", e.c);
            var3.a("Server: {}", var2);
            var3.a("");
            Files.createDirectories(var1);
            var3.a("Checking local metadata ...");
            G var4 = this.a(var1, var3);
            if (var4 != null) {
               Object[] var10002 = new Object[]{var4.c};
               var3.b("Valid (checksum " + String.format("%016x", var10002) + ")");
            } else {
               var3.b("Not available");
            }

            var3.a("Downloading remote metadata ...");
            Q var10001 = () -> this.a(var2, var4, var3);
            Objects.requireNonNull(var3);
            D var5 = (D)O.a("masmeta.bin", var10001, var3::a);
            G var6 = var5.a;
            var3.b("Done");
            this.b = var6;
            var3.a("Pack UUID: {}", var6.b);
            var3.a("Files in metadata: {}", var6.b().size());
            var3.a("");
            m var7 = null;
            if (l.a(var1)) {
               var7 = l.a(var1, var6, var3);
            }

            var3.a("Scanning local files ...");
            E var8 = new E(var1);
            var8.a(var6, var3);
            var3.b("Done");
            var3.a(0.0F);
            this.a(var1, var5.b);
            ArrayList var9 = new ArrayList();
            ArrayList var10 = new ArrayList();
            Map var11 = var6.b();

            for(Map.Entry var13 : var11.entrySet()) {
               String var14 = (String)var13.getKey();
               I var15 = (I)var13.getValue();
               if (var6.b(var14)) {
                  if (!var8.b().contains(var14)) {
                     var9.add(new C(var14, var15, true));
                  }
               } else if (!var8.a().contains(var15.e)) {
                  var9.add(new C(var14, var15, false));
               }
            }

            Path var38 = var1.resolve("masbin");
            if (Files.isDirectory(var38, new LinkOption[0])) {
               LongOpenHashSet var39 = new LongOpenHashSet();

               for(Map.Entry var47 : var11.entrySet()) {
                  if (!var6.b((String)var47.getKey())) {
                     var39.add(((I)var47.getValue()).e);
                  }
               }

               Stream var42 = Files.list(var38);

               try {
                  for(Path var16 : var42.toList()) {
                     if (Files.isDirectory(var16, new LinkOption[0])) {
                        Stream var17 = Files.list(var16);

                        try {
                           for(Path var19 : var17.toList()) {
                              if (Files.isRegularFile(var19, new LinkOption[0])) {
                                 String var20 = var19.getFileName().toString();
                                 if (var20.endsWith(".bin")) {
                                    String var21 = var20.substring(0, var20.length() - 4);

                                    try {
                                       long var22 = Long.parseUnsignedLong(var21, 16);
                                       boolean var24 = !String.format("%02x", (int)(var22 & 255L)).equals(var16.getFileName().toString());
                                       if (var24 || !var39.contains(var22)) {
                                          var10.add(var19);
                                       }
                                    } catch (NumberFormatException var33) {
                                       var10.add(var19);
                                    }
                                 }
                              }
                           }
                        } catch (Throwable var34) {
                           if (var17 != null) {
                              try {
                                 var17.close();
                              } catch (Throwable var29) {
                                 var34.addSuppressed(var29);
                              }
                           }

                           throw var34;
                        }

                        if (var17 != null) {
                           var17.close();
                        }
                     }
                  }
               } catch (Throwable var35) {
                  if (var42 != null) {
                     try {
                        var42.close();
                     } catch (Throwable var28) {
                        var35.addSuppressed(var28);
                     }
                  }

                  throw var35;
               }

               if (var42 != null) {
                  var42.close();
               }
            }

            Set var40 = var6.c();
            Stream var43 = Files.list(var1);

            try {
               for(Path var52 : var43.toList()) {
                  if (Files.isRegularFile(var52, new LinkOption[0])) {
                     String var55 = var52.getFileName().toString();
                     if (!var55.equals("masmeta.bin")) {
                        if (var55.endsWith(".tmp")) {
                           var10.add(var52);
                        } else if (!var40.contains(var55)) {
                           var10.add(var52);
                        }
                     }
                  }
               }
            } catch (Throwable var32) {
               if (var43 != null) {
                  try {
                     var43.close();
                  } catch (Throwable var27) {
                     var32.addSuppressed(var27);
                  }
               }

               throw var32;
            }

            if (var43 != null) {
               var43.close();
            }

            if (var9.isEmpty() && var10.isEmpty()) {
               var3.a("All files are up to date.");
               var3.a(1.0F);
               var3.a("");
               var3.a("Done! Thank you.");
               if (var7 != null) {
                  var7.a();
               }

               return true;
            } else {
               var3.a("Need to download: {} files, delete: {} files.", var9.size(), var10.size());
               if (!var9.isEmpty()) {
                  var3.a("Downloading files ...");
                  long var44 = System.currentTimeMillis();
                  J var53 = new J(var3);

                  for(C var59 : var9) {
                     String var60 = G.d(var59.b.e);
                     String var62 = var2 + "/" + var60;
                     Path var63;
                     long var65;
                     if (var59.c) {
                        var63 = var1.resolve(var59.a);
                        var65 = G.b(var59.b.d);
                     } else {
                        var63 = G.a(var1, var59.b.e);
                        var65 = G.b(var59.b.d);
                     }

                     K var66 = new K(var53, var62, var59.a, var59.b.c, var63, var65, var59.b.e, var59.c, var6.b);
                     var53.a(var66);
                  }

                  while(!var53.d()) {
                     var53.b();
                     var3.a();
                     Thread.sleep(33L);
                  }

                  var53.e();
                  long var57 = (System.currentTimeMillis() - var44) / 1000L;
                  long var61 = var53.c();
                  long var64 = var57 == 0L ? 0L : var61 / var57 / 1024L;
                  var3.a("", String.format("%.2f MiB in %02d:%02d, Average speed %d KiB/s", (float)var61 * 1.0F / 1024.0F / 1024.0F, var57 / 60L, var57 % 60L, var64));
               }

               if (!var10.isEmpty()) {
                  var3.a("Deleting obsolete files ...");

                  for(Path var50 : var10) {
                     Files.deleteIfExists(var50);
                  }

                  var3.b("Done");
               }

               if (Files.isDirectory(var38, new LinkOption[0])) {
                  var43 = Files.list(var38);

                  try {
                     for(Path var54 : var43.toList()) {
                        if (Files.isDirectory(var54, new LinkOption[0])) {
                           Stream var58 = Files.list(var54);

                           try {
                              if (var58.findAny().isEmpty()) {
                                 Files.deleteIfExists(var54);
                              }
                           } catch (Throwable var30) {
                              if (var58 != null) {
                                 try {
                                    var58.close();
                                 } catch (Throwable var26) {
                                    var30.addSuppressed(var26);
                                 }
                              }

                              throw var30;
                           }

                           if (var58 != null) {
                              var58.close();
                           }
                        }
                     }
                  } catch (Throwable var31) {
                     if (var43 != null) {
                        try {
                           var43.close();
                        } catch (Throwable var25) {
                           var31.addSuppressed(var25);
                        }
                     }

                     throw var31;
                  }

                  if (var43 != null) {
                     var43.close();
                  }
               }

               var3.a(1.0F);
               var3.a("");
               var3.a("Done! Thank you.");
               if (var7 != null) {
                  var7.a();
               }

               return true;
            }
         }
      } catch (w var36) {
         throw var36;
      } catch (Exception var37) {
         var3.a(var37);
         return false;
      }
   }

   private G a(Path var1, F var2) {
      Path var3 = var1.resolve("masmeta.bin");
      if (!Files.isRegularFile(var3, new LinkOption[0])) {
         return null;
      } else {
         try {
            return G.a(var3);
         } catch (Exception var7) {
            Exception var4 = var7;

            try {
               var2.a("[WARN] Local masmeta.bin invalid, will re-download: {}", var4.getMessage());
            } catch (Exception var6) {
            }

            return null;
         }
      }
   }

   private D a(String var1, G var2, F var3) {
      String var4 = var1 + "/masmeta.bin";
      URI var5 = URI.create(var4);
      HttpResponse var6 = K.a(var5, false);
      if (var6.statusCode() >= 400) {
         throw new IOException("Failed to download masmeta.bin: HTTP " + var6.statusCode());
      } else {
         long var7 = Long.parseLong((String)var6.headers().firstValue("Content-Length").orElse("-1"));
         InputStream var9 = (InputStream)var6.body();

         D var24;
         label74: {
            D var21;
            try {
               byte[] var10 = var9.readNBytes(48);
               if (var10.length < 48) {
                  throw new IOException("Remote masmeta.bin too short");
               }

               H var11 = G.a(var10);
               if (var2 != null && var2.c == var11.a() && var2.b.equals(var11.b())) {
                  var3.a(1.0F);
                  var24 = new D(var2, (byte[])null);
                  break label74;
               }

               long var12 = var7 > 0L ? var7 - 48L : -1L;
               ByteArrayOutputStream var14 = new ByteArrayOutputStream(var12 > 0L ? (int)var12 : 4096);
               byte[] var15 = new byte[8192];
               long var17 = 0L;

               int var16;
               while((var16 = var9.read(var15)) != -1) {
                  var14.write(var15, 0, var16);
                  var17 += (long)var16;
                  if (var12 > 0L) {
                     var3.a((float)var17 / (float)var12);
                  }
               }

               byte[] var19 = new byte[48 + var14.size()];
               System.arraycopy(var10, 0, var19, 0, 48);
               System.arraycopy(var14.toByteArray(), 0, var19, 48, var14.size());
               G var20 = G.b(var19);
               var21 = new D(var20, var19);
            } catch (Throwable var23) {
               if (var9 != null) {
                  try {
                     var9.close();
                  } catch (Throwable var22) {
                     var23.addSuppressed(var22);
                  }
               }

               throw var23;
            }

            if (var9 != null) {
               var9.close();
            }

            return var21;
         }

         if (var9 != null) {
            var9.close();
         }

         return var24;
      }
   }

   private void a(Path var1, byte[] var2) {
      if (var2 != null) {
         Path var3 = var1.resolve("masmeta.bin");
         Path var4 = var1.resolve("masmeta.bin.tmp");
         Files.write(var4, var2, new OpenOption[0]);
         G.a(var4, var3);
      }
   }
}
