package cn.zbx1425.resourcepackupdater;

import java.util.ArrayList;
import org.jetbrains.annotations.NotNull;

public class W implements Comparable {
   public final int[] a;

   private W(int[] var1) {
      this.a = var1;
   }

   public static W a(String var0) {
      ArrayList var1 = new ArrayList();
      String[] var2 = var0.split("-");

      for(int var3 = var2.length > 1 ? 1 : 0; var3 < var2.length; ++var3) {
         String[] var4 = var2[var3].split("\\.");

         for(String var8 : var4) {
            if (var8.matches("\\d+")) {
               var1.add(Integer.parseInt(var8));
            }
         }
      }

      return new W(var1.stream().mapToInt((var0x) -> var0x).toArray());
   }

   public int a(@NotNull W var1) {
      int var2 = Math.min(this.a.length, var1.a.length);

      for(int var3 = 0; var3 < var2; ++var3) {
         if (this.a[var3] != var1.a[var3]) {
            return Integer.compare(this.a[var3], var1.a[var3]);
         }
      }

      int[] var6 = this.a.length > var1.a.length ? this.a : var1.a;

      for(int var4 = var2; var4 < var6.length; ++var4) {
         if (var6[var4] != 0) {
            int var5 = Integer.signum(var6[var4]);
            return this.a.length > var1.a.length ? var5 : -var5;
         }
      }

      return 0;
   }

   public boolean b(String var1) {
      if (var1.isEmpty()) {
         return false;
      } else {
         switch (var1.charAt(0)) {
            case '<' -> {
               return this.a(a(var1.substring(1))) < 0;
            }
            case '=' -> {
               return this.a(a(var1.substring(1))) == 0;
            }
            case '>' -> {
               return this.a(a(var1.substring(1))) > 0;
            }
            default -> {
               return this.a(a(var1)) >= 0;
            }
         }
      }
   }

   // $FF: synthetic method
   public int compareTo(@NotNull Object var1) {
      return this.a((W)var1);
   }
}
