package cn.zbx1425.resourcepackupdater;

final class C extends Record {
   private final String a;
   private final I b;
   private final boolean c;

   private C(String var1, I var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public final String toString() {
      return this.toString<invokedynamic>(this);
   }

   public final int hashCode() {
      return this.hashCode<invokedynamic>(this);
   }

   public final boolean equals(Object var1) {
      return this.equals<invokedynamic>(this, var1);
   }

   public String a() {
      return this.a;
   }

   public I b() {
      return this.b;
   }

   public boolean c() {
      return this.c;
   }
}
