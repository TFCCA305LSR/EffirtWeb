package cn.zbx1425.resourcepackupdater;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1041;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_8251;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class v {
   private static class_5944 c;
   private static Matrix4f d;
   private static class_8251 e;
   public static final class_2960 a = new class_2960("resourcepackupdater", "textures/font/roboto.png");
   public static final z b;
   private static class_287 f;

   public static void a(float var0, float var1, float var2) {
      RenderSystem.clearColor(var0, var1, var2, 1.0F);
      RenderSystem.clear(16640, class_310.field_1703);
   }

   public static void a() {
      c = RenderSystem.getShader();
      RenderSystem.setShader(class_757::method_34543);
      RenderSystem.getModelViewStack().method_22903();
      RenderSystem.getModelViewStack().method_34426();
      RenderSystem.applyModelViewMatrix();
      d = RenderSystem.getProjectionMatrix();
      e = RenderSystem.getVertexSorting();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.disableCull();
   }

   public static void b() {
      RenderSystem.disableBlend();
      RenderSystem.enableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.getModelViewStack().method_22909();
      RenderSystem.applyModelViewMatrix();
      RenderSystem.setShader(() -> c);
      RenderSystem.setProjectionMatrix(d, e);
   }

   public static void a(class_2960 var0) {
      f = class_289.method_1348().method_1349();
      f.method_1328(class_5596.field_27382, class_290.field_1575);
      class_310.method_1551().method_1531().method_4619(var0).method_4527(true, false);
      RenderSystem.setShaderTexture(0, var0);
   }

   public static void c() {
      class_289.method_1348().method_1350();
   }

   public static void d() {
      class_1041 var0 = class_310.method_1551().method_22683();
      if (var0.method_22093()) {
         throw new w();
      } else {
         var0.method_15998();
      }
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      float var9 = var0 + var2;
      float var10 = var1 + var3;
      a(f.method_22912((double)var0, (double)var1, (double)1.0F).method_22913(var4, var5), var8).method_1344();
      a(f.method_22912((double)var9, (double)var1, (double)1.0F).method_22913(var6, var5), var8).method_1344();
      a(f.method_22912((double)var9, (double)var10, (double)1.0F).method_22913(var6, var7), var8).method_1344();
      a(f.method_22912((double)var0, (double)var10, (double)1.0F).method_22913(var4, var7), var8).method_1344();
   }

   public static void a(float var0, float var1, float var2, float var3, int var4) {
      float var5 = var0 + var2;
      float var6 = var1 + var3;
      a(f.method_22912((double)var0, (double)var1, (double)1.0F).method_22913(b.g, b.h), var4).method_1344();
      a(f.method_22912((double)var5, (double)var1, (double)1.0F).method_22913(b.g, b.h), var4).method_1344();
      a(f.method_22912((double)var5, (double)var6, (double)1.0F).method_22913(b.g, b.h), var4).method_1344();
      a(f.method_22912((double)var0, (double)var6, (double)1.0F).method_22913(b.g, b.h), var4).method_1344();
   }

   public static void a(float var0, float var1, float var2, float var3, float var4, String var5, int var6, boolean var7, boolean var8) {
      b(var0 + var4 / 16.0F, var1 + var4 / 16.0F, var2, var3, var4, var5, -14540254, var7, var8);
      b(var0, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public static void b(float var0, float var1, float var2, float var3, float var4, String var5, int var6, boolean var7, boolean var8) {
      float var9 = 0.0F;
      float var10 = 0.25F;
      float var11 = var0;
      float var12 = var1;

      for(char var16 : var5.toCharArray()) {
         if (var16 == '\n') {
            var12 += var4 + var10 * var4;
            var11 = var0;
         } else if (var16 != '\r') {
            if (var16 == '\t') {
               float var17 = (b.i + var9) * 8.0F * var4;
               var11 = (float)(Math.ceil((double)((var11 - var0) / var17)) * (double)var17 + (double)var0);
            } else if (var16 == ' ') {
               var11 += (b.i + var9) * var4;
            } else {
               A var19 = b.a(var16);
               float var18 = var19.i * var4;
               if (var11 + var18 + var9 * var4 > var0 + var2) {
                  if (var8) {
                     continue;
                  }

                  var12 += var4 + var10 * var4;
                  var11 = var0;
               }

               if (var12 + var4 > var1 + var3) {
                  return;
               }

               a(var11 + var19.g * var4, var12 + (b.d + var19.h) * var4, var19.e * var4, var19.f * var4, var19.a, var19.b, var19.c, var19.d, var6);
               var11 += var18 + var9 * var4;
            }
         }
      }

   }

   public static float a(String var0, float var1) {
      float var2 = 0.0F;
      float var3 = 0.0F;
      float var4 = 0.0F;

      for(char var8 : var0.toCharArray()) {
         if (var8 == '\n') {
            var3 = Math.max(var3, var4);
            var4 = 0.0F;
         } else if (var8 != '\r') {
            if (var8 == '\t') {
               float var9 = (b.i + var2) * 8.0F * var1;
               var4 = (float)(Math.ceil((double)(var4 / var9)) * (double)var9);
            } else if (var8 == ' ') {
               var4 += (b.i + var2) * var1;
            } else {
               A var10 = b.a(var8);
               var4 += var10.i * var1 + var2 * var1;
            }
         }
      }

      return Math.max(var3, var4);
   }

   public static void e() {
      RenderSystem.getModelViewStack().method_34426();
   }

   public static void f() {
      Matrix4f var0 = new Matrix4f();
      var0.scale(2.0F, -2.0F, 1.0F);
      var0.translate(-0.5F, -0.5F, 0.0F);
      float var1 = (float)class_310.method_1551().method_22683().method_4489();
      float var2 = (float)class_310.method_1551().method_22683().method_4506();
      var0.scale(1.0F / var1, 1.0F / var2, 1.0F);
      RenderSystem.setProjectionMatrix(var0, class_8251.field_43361);
   }

   public static void g() {
      Matrix4f var0 = new Matrix4f();
      var0.scale(2.0F, -2.0F, 1.0F);
      var0.translate(-0.5F, -0.5F, 0.0F);
      var0.scale(1.0F / (float)h(), 1.0F / (float)i(), 1.0F);
      RenderSystem.setProjectionMatrix(var0, class_8251.field_43361);
   }

   public static int h() {
      int var0 = class_310.method_1551().method_22683().method_4489();
      if (var0 < 854) {
         return var0;
      } else {
         return var0 < 1920 ? (int)((float)(var0 - 854) * 1.0F / 1066.0F * 512.0F + 854.0F) : 1366;
      }
   }

   public static int i() {
      int var0 = class_310.method_1551().method_22683().method_4489();
      int var1 = class_310.method_1551().method_22683().method_4506();
      return (int)((float)var1 * ((float)h() * 1.0F / (float)var0));
   }

   public static void b(float var0, float var1, float var2) {
      Matrix4f var3 = new Matrix4f();
      var3.scale(2.0F, -2.0F, 1.0F);
      var3.translate(-0.5F, -0.5F, 0.0F);
      float var4 = (float)class_310.method_1551().method_22683().method_4489();
      float var5 = (float)class_310.method_1551().method_22683().method_4506();
      var3.scale(1.0F / var4, 1.0F / var5, 1.0F);
      float var6 = var4 * var2;
      float var7 = var1 / var0 * var6;
      var3.translate((var4 - var6) / 2.0F, (var5 - var7) / 2.0F, 0.0F);
      var3.scale(var6 / var0, var7 / var1, 1.0F);
      RenderSystem.setProjectionMatrix(var3, class_8251.field_43361);
   }

   public static void a(float var0, float var1, float var2, float var3) {
      Matrix4f var4 = RenderSystem.getProjectionMatrix();
      Vector3f var5 = var4.transformPosition(new Vector3f(var0, var1 + var3, 0.0F));
      Vector3f var6 = var4.transformPosition(new Vector3f(var0 + var2, var1, 0.0F));
      float var7 = class_3532.method_37959(var5.x, -1.0F, 1.0F, 0.0F, (float)class_310.method_1551().method_22683().method_4489());
      float var8 = class_3532.method_37959(var5.y, -1.0F, 1.0F, 0.0F, (float)class_310.method_1551().method_22683().method_4506());
      float var9 = class_3532.method_37959(var6.x, -1.0F, 1.0F, 0.0F, (float)class_310.method_1551().method_22683().method_4489());
      float var10 = class_3532.method_37959(var6.y, -1.0F, 1.0F, 0.0F, (float)class_310.method_1551().method_22683().method_4506());
      RenderSystem.enableScissor((int)var7, (int)var8, (int)(var9 - var7), (int)(var10 - var8));
   }

   public static void j() {
      RenderSystem.disableScissor();
   }

   private static class_4588 a(class_4588 var0, int var1) {
      int var2 = var1 >>> 24 & 255;
      int var3 = var1 >>> 16 & 255;
      int var4 = var1 >>> 8 & 255;
      int var5 = var1 & 255;
      return var0.method_1336(var3, var4, var5, var2);
   }

   static {
      b = new z(a);
   }
}
