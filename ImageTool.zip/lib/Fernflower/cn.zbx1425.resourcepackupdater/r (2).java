package cn.zbx1425.resourcepackupdater;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class r implements s {
   private final List c = new ArrayList();
   private int d = 0;
   private Exception e;
   private static final int f = 20;
   private static final float g = 100.0F;

   public void a() {
      v.g();
      v.a(v.a);
      v.a(0.0F, 0.0F, (float)v.h(), (float)v.i(), -2013265920);
      if (this.e != null) {
         v.a(20.0F, 20.0F, (float)(v.h() - 40), 30.0F, 24.0F, "There was an error! Please report.", -65536, false, true);
      }

      v.a((float)(v.h() - 240 - 20), 20.0F, 240.0F, 16.0F, 16.0F, "Arrow Keys to Scroll", -2236963, false, true);
      int var1 = System.currentTimeMillis() % 400L >= 200L ? -256 : -2236963;
      v.a(20.0F, 50.0F, (float)(v.h() - 40), 30.0F, 24.0F, "Press ENTER to continue without the resource pack.", var1, false, true);
      boolean var2 = true;
      float var3 = 100.0F;
      float var4 = (float)v.i() - var3 - 20.0F;

      for(int var5 = this.d; var5 < this.c.size(); ++var5) {
         v.a(20.0F, var3 + (float)(20 * (var5 - this.d)), (float)(v.h() - 40), var4, 16.0F, (String)this.c.get(var5), -2236963, false, true);
      }

      v.c();
   }

   public boolean b() {
      long var1 = class_310.method_1551().method_22683().method_4490();
      float var3 = (float)v.i() - 100.0F - 20.0F;
      int var4 = (int)Math.floor((double)(var3 / 20.0F));
      int var5 = Math.max(0, this.c.size() - var4);
      if (class_3675.method_15987(var1, 268)) {
         this.d = 0;
      } else if (class_3675.method_15987(var1, 269)) {
         this.d = var5;
      } else if (class_3675.method_15987(var1, 266)) {
         this.d = Math.max(0, this.d - var4);
      } else if (class_3675.method_15987(var1, 267)) {
         this.d = Math.min(var5, this.d + var4);
      } else if (class_3675.method_15987(var1, 265)) {
         this.d = Math.max(0, this.d - 1);
      } else if (class_3675.method_15987(var1, 264)) {
         this.d = Math.min(var5, this.d + 1);
      }

      return class_3675.method_15987(var1, 257);
   }

   public void c() {
      this.c.clear();
      this.e = null;
   }

   public void a(String var1) {
      this.c.add(var1);
      float var2 = (float)v.i() - 100.0F - 20.0F;
      int var3 = (int)Math.floor((double)(var2 / 20.0F));
      this.d = Math.max(0, this.c.size() - var3);
   }

   public void b(String var1) {
      if (!this.c.isEmpty()) {
         List var10000 = this.c;
         int var10001 = this.c.size() - 1;
         String var10002 = (String)this.c.get(this.c.size() - 1);
         var10000.set(var10001, var10002 + var1);
      }
   }

   public void a(float var1) {
   }

   public void a(String var1, String var2) {
   }

   public void a(Exception var1) {
      this.e = var1;
      this.a("");
      this.a("Update failed with this exception: ");

      for(String var5 : var1.toString().split("\n")) {
         this.a(var5);
      }

   }
}
