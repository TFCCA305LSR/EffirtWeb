package cn.zbx1425.resourcepackupdater;

import net.fabricmc.fabric.api.networking.v1.FabricPacket;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class S implements FabricPacket {
   public static final PacketType a = PacketType.create(new class_2960("zbx_rpu", "client_version"), S::new);
   public final String b;
   public final String c;

   public S(String var1, String var2) {
      this.b = var1;
      this.c = var2;
   }

   public S(class_2540 var1) {
      this.b = var1.method_19772();
      this.c = var1.isReadable() ? var1.method_19772() : "";
   }

   public void write(class_2540 var1) {
      var1.method_10814(this.b);
      var1.method_10814(this.c);
   }

   public PacketType getType() {
      return a;
   }
}
