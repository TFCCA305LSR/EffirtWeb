package cn.zbx1425.resourcepackupdater;

final class D extends Record {
   private final G a;
   private final byte[] b;

   private D(G var1, byte[] var2) {
      this.a = var1;
      this.b = var2;
   }

   public final String toString() {
      return this.toString<invokedynamic>(this);
   }

   public final int hashCode() {
      return this.hashCode<invokedynamic>(this);
   }

   public final boolean equals(Object var1) {
      return this.equals<invokedynamic>(this, var1);
   }

   public G a() {
      return this.a;
   }

   public byte[] b() {
      return this.b;
   }
}
