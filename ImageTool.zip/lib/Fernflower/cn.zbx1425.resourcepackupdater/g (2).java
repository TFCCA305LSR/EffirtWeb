package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import eu.pb4.banhammer.api.BanHammer;
import eu.pb4.banhammer.api.PunishmentData;
import eu.pb4.banhammer.api.PunishmentType;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_8610;

public class g {
   private static final HttpClient a = HttpClient.newHttpClient();

   public static boolean a(String var0, String var1, class_8610 var2) {
      try {
         j var3 = e.f;
         if (var3 == null) {
            throw new IllegalStateException("Device Mapping not Loaded?");
         } else {
            HashMap var4 = new HashMap();
            if (var0 != null && !var0.isEmpty()) {
               for(String var6 : var3.a(var0)) {
                  if (!var6.equals(var1)) {
                     var4.put(var6, var0);
                  }
               }
            }

            for(String var16 : var3.b(var1)) {
               for(String var8 : var3.a(var16)) {
                  if (!var8.equals(var1)) {
                     var4.putIfAbsent(var8, var16);
                  }
               }
            }

            Iterator var15 = var4.entrySet().iterator();

            while(true) {
               Map.Entry var17;
               UUID var18;
               while(true) {
                  if (!var15.hasNext()) {
                     return false;
                  }

                  var17 = (Map.Entry)var15.next();

                  try {
                     var18 = UUID.fromString((String)var17.getKey());
                     break;
                  } catch (IllegalArgumentException var12) {
                  }
               }

               Collection var19;
               if (BanHammer.isPunished(var18, PunishmentType.BAN)) {
                  var19 = BanHammer.getPunishments(var18, PunishmentType.BAN);
               } else {
                  if (!BanHammer.isPunished(var18, PunishmentType.IP_BAN)) {
                     continue;
                  }

                  var19 = BanHammer.getPunishments(var18, PunishmentType.IP_BAN);
               }

               if (!var19.isEmpty()) {
                  PunishmentData.Synced var9 = (PunishmentData.Synced)var19.iterator().next();
                  GameProfile var10 = var2.method_52404();
                  String var11 = (String)var17.getValue();
                  e.b.warn("DeviceBan: Blocking {} ({}) - shares device [{}] with banned account {} ({}). Reason: {}", var10.getName(), var1, a(var11), var9.playerName, var9.playerUUID, var9.reason);
                  a(var10.getName(), var1, var9, var11);
                  var2.method_52396(var9.getDisconnectMessage());
                  return true;
               }
            }
         }
      } catch (Exception var13) {
         e.b.error("Error during DeviceBan check", var13);
         return false;
      }
   }

   private static void a(String var0, String var1, PunishmentData var2, String var3) {
      List var4 = a();
      if (!var4.isEmpty()) {
         JsonObject var5 = new JsonObject();
         var5.addProperty("title", "DeviceBan: Alt Account Detected");
         var5.addProperty("color", 15158332);
         JsonArray var6 = new JsonArray();
         JsonObject var7 = new JsonObject();
         var7.addProperty("name", "Joining Player");
         var7.addProperty("value", var0 + " (`" + var1 + "`)");
         var7.addProperty("inline", true);
         var6.add(var7);
         JsonObject var8 = new JsonObject();
         var8.addProperty("name", "Banned Account");
         String var10002 = var2.playerName;
         var8.addProperty("value", var10002 + " (`" + String.valueOf(var2.playerUUID) + "`)");
         var8.addProperty("inline", true);
         var6.add(var8);
         JsonObject var9 = new JsonObject();
         var9.addProperty("name", "Ban Reason");
         var9.addProperty("value", var2.reason);
         var9.addProperty("inline", false);
         var6.add(var9);
         JsonObject var10 = new JsonObject();
         var10.addProperty("name", "Device ID");
         var10.addProperty("value", "`" + a(var3) + "`");
         var10.addProperty("inline", true);
         var6.add(var10);
         var5.add("fields", var6);
         JsonArray var11 = new JsonArray();
         var11.add(var5);
         JsonObject var12 = new JsonObject();
         var12.add("embeds", var11);
         String var13 = var12.toString();
         HttpRequest.BodyPublisher var14 = BodyPublishers.ofString(var13);

         for(URI var16 : var4) {
            a.sendAsync(HttpRequest.newBuilder(var16).header("Content-Type", "application/json").POST(var14).build(), BodyHandlers.discarding());
         }

      }
   }

   private static List a() {
      try {
         Path var0 = FabricLoader.getInstance().getConfigDir().resolve("banhammer").resolve("config.json");
         if (!Files.isRegularFile(var0, new LinkOption[0])) {
            return Collections.emptyList();
         } else {
            String var1 = Files.readString(var0);
            JsonObject var2 = e.e.parse(var1).getAsJsonObject();
            if (!var2.has("discordWebhookUrls")) {
               return Collections.emptyList();
            } else {
               JsonArray var3 = var2.getAsJsonArray("discordWebhookUrls");
               ArrayList var4 = new ArrayList();

               for(JsonElement var6 : var3) {
                  String var7 = var6.getAsString();
                  if (var7 != null && !var7.isEmpty()) {
                     var4.add(URI.create(var7));
                  }
               }

               return var4;
            }
         }
      } catch (Exception var8) {
         e.b.warn("Failed to read BanHammer webhook config", var8);
         return Collections.emptyList();
      }
   }

   private static String a(String var0) {
      return var0.length() > 20 ? var0.substring(0, 20) + "..." : var0;
   }
}
