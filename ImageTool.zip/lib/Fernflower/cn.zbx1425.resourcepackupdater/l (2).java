package cn.zbx1425.resourcepackupdater;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class l {
   private static final String a = "updater_hash_cache.bin";

   public static boolean a(Path var0) {
      return Files.isRegularFile(var0.resolve("updater_hash_cache.bin"), new LinkOption[0]);
   }

   public static m a(Path var0, G var1, F var2) {
      var2.a("Existing synced pack is in v2 format. Migrating ...");
      Map var3 = var1.b();
      Long2ObjectOpenHashMap var4 = new Long2ObjectOpenHashMap();

      for(Map.Entry var6 : var3.entrySet()) {
         ((List)var4.computeIfAbsent(((I)var6.getValue()).e, (var0x) -> new ArrayList())).add(var6);
      }

      int var33 = 0;
      int var34 = 0;
      int var7 = 0;
      ArrayList var8 = new ArrayList();
      Stream var9 = Files.walk(var0);

      try {
         for(Path var11 : var9.toList()) {
            if (Files.isRegularFile(var11, new LinkOption[0])) {
               String var12 = var0.relativize(var11).toString().replace('\\', '/');
               if (!var12.equals("updater_hash_cache.bin") && !var12.startsWith("masbin/") && !var12.equals("masmeta.bin")) {
                  var8.add(var11);
                  ++var7;
               }
            }
         }
      } catch (Throwable var32) {
         if (var9 != null) {
            try {
               var9.close();
            } catch (Throwable var27) {
               var32.addSuppressed(var27);
            }
         }

         throw var32;
      }

      if (var9 != null) {
         var9.close();
      }

      SecureRandom var35 = new SecureRandom();

      for(Path var37 : var8) {
         byte[] var38;
         try {
            FileInputStream var13 = new FileInputStream(var37.toFile());

            try {
               InputStream var14 = k.b(var13);
               var38 = var14.readAllBytes();
            } catch (Throwable var30) {
               try {
                  var13.close();
               } catch (Throwable var28) {
                  var30.addSuppressed(var28);
               }

               throw var30;
            }

            var13.close();
         } catch (Exception var31) {
            var2.a("[WARN] Failed to read v2 resource file {}: {}", var37, var31.getMessage());
            ++var34;
            continue;
         }

         long var39 = G.c(var38);
         List var15 = (List)var4.get(var39);
         if (var15 != null && !var15.isEmpty()) {
            Map.Entry var16 = (Map.Entry)var15.get(0);
            String var17 = (String)var16.getKey();
            if (var1.b(var17)) {
               Path var18 = var0.resolve(var17);
               Files.createDirectories(var18.getParent());
               Path var19 = var18.resolveSibling(String.valueOf(var18.getFileName()) + ".mig.tmp");
               Files.write(var19, var38, new OpenOption[0]);
               G.a(var19, var18);
            } else {
               Path var41 = G.a(var0, var39);
               Files.createDirectories(var41.getParent());
               byte[] var42 = new byte[16];
               var35.nextBytes(var42);
               byte[] var20 = n.a(var1.b, var39);
               byte[] var21 = n.b(var38, var20, var42);
               Path var22 = var41.resolveSibling(String.valueOf(var41.getFileName()) + ".mig.tmp");
               BufferedOutputStream var23 = new BufferedOutputStream(Files.newOutputStream(var22));

               try {
                  ((OutputStream)var23).write(var42);
                  ((OutputStream)var23).write(var21);
               } catch (Throwable var29) {
                  try {
                     ((OutputStream)var23).close();
                  } catch (Throwable var26) {
                     var29.addSuppressed(var26);
                  }

                  throw var29;
               }

               ((OutputStream)var23).close();
               G.a(var22, var41);
               long var43 = G.b(((I)var16.getValue()).d);
               Files.setLastModifiedTime(var41, FileTime.fromMillis(var43));
            }

            ++var33;
         } else {
            ++var34;
         }

         int var40 = var33 + var34;
         if (var40 % 50 == 0) {
            var2.a((float)var40 / (float)var7);
            var2.a(var40 + " / " + var7, "");
         }
      }

      var2.a("Migration complete: {} migrated, {} discarded.", var33, var34);
      var2.a(0.0F);
      return new m(var0, var1, var8);
   }

   private static void b(Path var0) {
      Stream var1 = Files.walk(var0);

      try {
         for(Path var4 : var1.filter((var0x) -> Files.isDirectory(var0x, new LinkOption[0])).filter((var1x) -> !var1x.equals(var0)).sorted(Comparator.reverseOrder()).toList()) {
            String var5 = var0.relativize(var4).toString().replace('\\', '/');
            if (!var5.equals("masbin") && !var5.startsWith("masbin/")) {
               Stream var6 = Files.list(var4);

               try {
                  if (var6.findAny().isEmpty()) {
                     Files.deleteIfExists(var4);
                  }
               } catch (Throwable var11) {
                  if (var6 != null) {
                     try {
                        var6.close();
                     } catch (Throwable var10) {
                        var11.addSuppressed(var10);
                     }
                  }

                  throw var11;
               }

               if (var6 != null) {
                  var6.close();
               }
            }
         }
      } catch (Throwable var12) {
         if (var1 != null) {
            try {
               var1.close();
            } catch (Throwable var9) {
               var12.addSuppressed(var9);
            }
         }

         throw var12;
      }

      if (var1 != null) {
         var1.close();
      }

   }
}
