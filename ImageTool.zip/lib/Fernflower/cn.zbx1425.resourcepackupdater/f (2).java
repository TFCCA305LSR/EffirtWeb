package cn.zbx1425.resourcepackupdater;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3283;

public class f implements ClientModInitializer {
   public static final q a = new q();
   public static final HttpClient b;

   public void onInitializeClient() {
      ClientConfigurationConnectionEvents.INIT.register((ClientConfigurationConnectionEvents.Init)(var0, var1) -> o.b());
      ClientConfigurationNetworking.registerGlobalReceiver(T.a, (var0, var1) -> {
         o.a(var0.b);
         var1.sendPacket(new S(e.c, i.a()));
      });
      ClientConfigurationConnectionEvents.READY.register((ClientConfigurationConnectionEvents.Ready)(var0, var1) -> o.c());
   }

   public static void a() {
      v.a();

      while(true) {
         B var0 = new B();
         if (e.d.c.a == null || ((c)e.d.c.a).b.isEmpty()) {
            if (((List)e.d.b.a).size() > 1) {
               a.c();

               try {
                  while(a.a(true)) {
                     Thread.sleep(50L);
                  }
               } catch (w var9) {
                  o.a = true;
                  break;
               } catch (Exception var10) {
               }
            } else if (((List)e.d.b.a).size() == 1) {
               e.d.c.a = ((List)e.d.b.a).get(0);
               e.d.c.b = true;
            } else {
               e.d.c.a = new c("NOT CONFIGURED", "", true);
            }
         }

         a.b();

         try {
            for(String var2 : e.d.l) {
               a.a(var2);
            }

            e.d.l.clear();
            if (e.d.k != null) {
               a.a("[WARN] " + e.d.k);
               a.a("");
            }

            Path var11 = (Path)e.d.f.a;
            String var12 = ((c)e.d.c.a).b;
            boolean var3 = var0.a((Path)var11, (String)var12, a);
            if (var3) {
               o.a = false;
               e.a(var0.a());
            } else {
               o.a = true;
            }

            class_310.method_1551().field_1690.method_1640();

            try {
               e.d.b();
            } catch (IOException var5) {
            }
            break;
         } catch (w var7) {
            o.a = true;
            e.d.c.a = new c("NOT CONFIGURED", "", true);
            if (((List)e.d.b.a).size() <= 1) {
               break;
            }
         } catch (Exception var8) {
            o.a = true;
            break;
         }
      }

      try {
         while(a.a(true)) {
            Thread.sleep(50L);
         }
      } catch (Exception var6) {
      }

      o.a((Path)e.d.f.a);
      v.b();
   }

   public static void b() {
      class_315 var0 = class_310.method_1551().field_1690;
      String var1 = "file/" + (String)e.d.d.a;
      var0.field_1887.remove(var1);
      if (!var0.field_1887.contains("vanilla")) {
         var0.field_1887.add("vanilla");
      }

      if (!var0.field_1887.contains("Fabric Mods")) {
         var0.field_1887.add("Fabric Mods");
      }

      var0.field_1887.add(var1);
      var0.field_1846.remove(var1);
      class_3283 var2 = class_310.method_1551().method_1520();
      var2.method_14445();
      var0.method_1627(var2);
   }

   static {
      ExecutorService var0 = Executors.newFixedThreadPool(4);
      b = HttpClient.newBuilder().followRedirects(Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10L)).executor(var0).build();
   }
}
