package cn.zbx1425.resourcepackupdater;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class j {
   private final ConcurrentHashMap a = new ConcurrentHashMap();
   private final ConcurrentHashMap b = new ConcurrentHashMap();
   private final Path c;
   private volatile boolean d = false;

   public j(Path var1) {
      this.c = var1;
   }

   public void a(String var1, String var2) {
      boolean var3 = false;
      var3 |= ((Set)this.a.computeIfAbsent(var1, (var0) -> ConcurrentHashMap.newKeySet())).add(var2);
      var3 |= ((Set)this.b.computeIfAbsent(var2, (var0) -> ConcurrentHashMap.newKeySet())).add(var1);
      if (var3) {
         this.d = true;
      }

   }

   public Set a(String var1) {
      return Collections.unmodifiableSet((Set)this.a.getOrDefault(var1, Collections.emptySet()));
   }

   public Set b(String var1) {
      return Collections.unmodifiableSet((Set)this.b.getOrDefault(var1, Collections.emptySet()));
   }

   public void a() {
      this.a.clear();
      this.b.clear();
      this.d = false;
      if (Files.isRegularFile(this.c, new LinkOption[0])) {
         try {
            String var1 = Files.readString(this.c);
            JsonObject var2 = e.e.parse(var1).getAsJsonObject();
            if (!var2.has("mappings")) {
               return;
            }

            JsonObject var3 = var2.getAsJsonObject("mappings");

            for(Map.Entry var5 : var3.entrySet()) {
               String var6 = (String)var5.getKey();

               for(JsonElement var8 : ((JsonElement)var5.getValue()).getAsJsonArray()) {
                  this.a(var6, var8.getAsString());
               }
            }

            this.d = false;
            e.b.info("Loaded {} device ID mappings", this.a.size());
         } catch (Exception var9) {
            e.b.error("Failed to load device ID store from {}", this.c, var9);
         }

      }
   }

   public void b() {
      if (this.d) {
         try {
            JsonObject var1 = new JsonObject();
            var1.addProperty("version", 1);
            JsonObject var2 = new JsonObject();

            for(Map.Entry var4 : this.a.entrySet()) {
               JsonArray var5 = new JsonArray();

               for(String var7 : (Set)var4.getValue()) {
                  var5.add(var7);
               }

               var2.add((String)var4.getKey(), var5);
            }

            var1.add("mappings", var2);
            Files.createDirectories(this.c.getParent());
            Files.writeString(this.c, (new GsonBuilder()).setPrettyPrinting().create().toJson(var1));
            this.d = false;
         } catch (Exception var8) {
            e.b.error("Failed to save device ID store to {}", this.c, var8);
         }

      }
   }
}
