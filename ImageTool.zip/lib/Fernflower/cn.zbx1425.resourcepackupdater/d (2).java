package cn.zbx1425.resourcepackupdater;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class d implements ModMenuApi {
   public ConfigScreenFactory getModConfigScreenFactory() {
      return (var0) -> new p();
   }
}
