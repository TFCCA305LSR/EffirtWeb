package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_370;
import net.minecraft.class_370.class_9037;

public class o {
   public static boolean a = true;
   private static String b;
   private static String c;
   private static String d;
   private static boolean e = false;

   public static void a(Path var0) {
      if (a) {
         b = null;
      } else {
         G var1 = cn.zbx1425.resourcepackupdater.e.a();
         if (var1 == null) {
            b = null;
         } else {
            try {
               String var2 = a(var0, var1);
               b = var2;
               if (b != null && !e) {
                  c = b;
                  d = c;
                  cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination info prefetched from local pack.");
                  e = true;
               }
            } catch (Exception var3) {
               cn.zbx1425.resourcepackupdater.e.b.warn("Failed to read asset coordination info: {}", var3.getMessage());
               b = null;
            }

         }
      }
   }

   private static String a(Path var0, G var1) {
      I var2 = var1.a("macrosync/server_lock.json");
      if (var2 == null) {
         return null;
      } else {
         Path var3 = G.a(var0, var2.e);
         if (!Files.exists(var3, new LinkOption[0])) {
            return null;
         } else {
            BufferedInputStream var4 = new BufferedInputStream(Files.newInputStream(var3));

            String var10;
            label59: {
               try {
                  byte[] var5 = ((InputStream)var4).readNBytes(16);
                  byte[] var6 = n.a(var1.b, var2.e);
                  InputStream var7 = n.a((InputStream)var4, var6, var5);

                  label67: {
                     try {
                        String var8 = new String(var7.readAllBytes(), StandardCharsets.UTF_8);
                        JsonObject var9 = JsonParser.parseString(var8).getAsJsonObject();
                        if (!var9.has("serverLockKey")) {
                           break label67;
                        }

                        var10 = var9.get("serverLockKey").getAsString();
                     } catch (Throwable var13) {
                        if (var7 != null) {
                           try {
                              var7.close();
                           } catch (Throwable var12) {
                              var13.addSuppressed(var12);
                           }
                        }

                        throw var13;
                     }

                     if (var7 != null) {
                        var7.close();
                     }
                     break label59;
                  }

                  if (var7 != null) {
                     var7.close();
                  }
               } catch (Throwable var14) {
                  try {
                     ((InputStream)var4).close();
                  } catch (Throwable var11) {
                     var14.addSuppressed(var11);
                  }

                  throw var14;
               }

               ((InputStream)var4).close();
               return null;
            }

            ((InputStream)var4).close();
            return var10;
         }
      }
   }

   public static boolean a() {
      if (a) {
         return true;
      } else if (b == null) {
         return false;
      } else {
         return !Objects.equals(b, c);
      }
   }

   public static void b() {
      c = null;
   }

   public static void a(String var0) {
      c = var0;
   }

   public static void c() {
      if (a) {
         class_310.method_1551().method_1566().method_1999(new class_370(class_9037.field_47585, R.a("同步資源包不完整而未被采用"), R.a("您可按 F3+T 重試下載。如有錯誤請聯絡管理人員。")));
         class_310.method_1551().method_1566().method_1999(new class_370(class_9037.field_47585, R.a("Synced Resource Pack Incomplete and Thus not Used"), R.a("Press F3+T to download again. Ask the staff when error.")));
      }

      if (b == null) {
         cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination not required.");
      } else if (c == null) {
         cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination received no cooperation.");
      } else if (!c.equals(b)) {
         cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination received discrepancy.");
      } else if (a) {
         cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination is unavailable for incompleteness.");
      } else {
         cn.zbx1425.resourcepackupdater.e.b.info("Asset coordination is applicable.");
      }

      if (b != null && !Objects.equals(d, c)) {
         d = c;
         class_310.method_1551().execute(() -> class_310.method_1551().method_1521());
      }

   }
}
