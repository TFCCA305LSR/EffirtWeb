package cn.zbx1425.resourcepackupdater;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class m {
   private final Path a;
   private final G b;
   private final List c;

   private m(Path var1, G var2, List var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void a() {
      for(Path var2 : this.c) {
         String var3 = this.a.relativize(var2).toString().replace('\\', '/');
         if (!this.b.b(var3)) {
            Files.deleteIfExists(var2);
         }
      }

      Files.deleteIfExists(this.a.resolve("updater_hash_cache.bin"));
      l.b(this.a);
   }
}
