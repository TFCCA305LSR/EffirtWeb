package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonObject;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class c {
   public String a;
   public String b;
   public boolean c;

   public c(String var1, String var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public c(JsonObject var1) {
      this.a = var1.get("name").getAsString();
      this.b = var1.get("baseUrl").getAsString();
      this.c = false;
   }

   public JsonObject a() {
      JsonObject var1 = new JsonObject();
      var1.addProperty("name", this.a);
      var1.addProperty("baseUrl", this.b);
      return var1;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         c var2 = (c)var1;
         return (new EqualsBuilder()).append(this.b, var2.b).isEquals();
      } else {
         return false;
      }
   }

   public int hashCode() {
      return (new HashCodeBuilder(17, 37)).append(this.b).toHashCode();
   }
}
