package cn.zbx1425.resourcepackupdater;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class t implements s {
   private String c = "";
   private String d = "";
   private float e;
   private String f;
   private static final float g = 600.0F;
   private static final float h = 250.0F;

   public void a() {
      v.b(600.0F, 250.0F, 0.75F);
      v.a(v.a);
      s.a(600.0F, 250.0F, -2169110);
      float var1 = 0.0F;
      float var2 = 600.0F - var1 - 0.0F;
      float var3 = 300.0F - v.a("88%", 16.0F) / 2.0F;
      v.a(var1, 0.0F, var2, 30.0F, 1144367758);
      v.b(var3, 10.0F, 80.0F, 30.0F, 16.0F, String.format("%d%%", Math.round(this.e * 100.0F)), -13464971, false, true);
      v.c();
      v.a(v.a);
      v.a(0.0F, 0.0F, var2 * this.e, 30.0F);
      v.a(var1, 0.0F, var2, 30.0F, -13260146);
      v.b(var3, 10.0F, 80.0F, 30.0F, 16.0F, String.format("%d%%", Math.round(this.e * 100.0F)), -1, false, true);
      v.c();
      v.a(v.a);
      v.j();
      v.b(20.0F, 45.0F, 560.0F, 50.0F, 20.0F, this.c, -14540254, false, false);
      if (this.f.contains("\n")) {
         v.a(0.0F, 70.0F, 600.0F, 115.0F, 865708971);
      }

      v.b(20.0F, 80.0F, 560.0F, 100.0F, 16.0F, this.f, -14540254, false, true);
      boolean var4 = !this.d.isEmpty() && this.d.charAt(0) == ':';
      v.b(20.0F, 195.0F, 560.0F, 30.0F, 18.0F, var4 ? this.d.substring(1) : this.d, -14540254, var4, false);
      String var5 = ((List)cn.zbx1425.resourcepackupdater.e.d.b.a).size() > 1 ? "Cancel / Use Another Source" : "Cancel";
      v.b(20.0F, 220.0F, 560.0F, 16.0F, 16.0F, "(" + var5 + ": Hold ESC)", -14540254, false, true);
      v.c();
   }

   public boolean b() {
      if (class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), 256)) {
         throw new w();
      } else {
         return true;
      }
   }

   public void c() {
      this.c = "";
      this.d = "";
      this.e = 0.0F;
      this.f = "";
   }

   public void a(String var1) {
      this.c = var1;
   }

   public void b(String var1) {
   }

   public void a(float var1) {
      this.e = var1;
   }

   public void a(String var1, String var2) {
      this.f = var1;
      this.d = var2;
   }

   public void a(Exception var1) {
   }
}
