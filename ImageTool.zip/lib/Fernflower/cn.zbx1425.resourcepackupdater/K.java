package cn.zbx1425.resourcepackupdater;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.Duration;
import java.util.UUID;
import org.apache.commons.io.IOUtils;

public class K {
   public long a;
   public long b;
   public final long c;
   protected final J d;
   private final URI g;
   private final Path h;
   private final long i;
   private final long j;
   private final boolean k;
   private final UUID l;
   public String e;
   public int f = 0;

   public K(J var1, String var2, String var3, long var4, Path var6, long var7, long var9, boolean var11, UUID var12) {
      this.d = var1;
      this.g = URI.create(var2);
      this.e = var3;
      this.c = var4;
      this.h = var6;
      this.i = var7;
      this.j = var9;
      this.k = var11;
      this.l = var12;
   }

   public void a() {
      HttpResponse var1 = a(this.g);
      if (var1.statusCode() >= 400) {
         int var10002 = var1.statusCode();
         throw new IOException("Server returned HTTP " + var10002 + " " + new String(((InputStream)var1.body()).readAllBytes(), StandardCharsets.UTF_8));
      } else {
         this.a = (Long)var1.headers().firstValue("Content-Length").map(Long::parseLong).orElse(this.c);
         Path var2 = this.h.resolveSibling(String.valueOf(this.h.getFileName()) + ".tmp");
         Files.createDirectories(this.h.getParent());

         try {
            BufferedOutputStream var3 = new BufferedOutputStream(Files.newOutputStream(var2));

            try {
               InputStream var4 = (InputStream)var1.body();

               try {
                  M var5 = new M(var3, new L(this));
                  IOUtils.copy(new BufferedInputStream(var4), var5);
               } catch (Throwable var9) {
                  if (var4 != null) {
                     try {
                        var4.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (var4 != null) {
                  var4.close();
               }
            } catch (Throwable var10) {
               try {
                  ((OutputStream)var3).close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }

               throw var10;
            }

            ((OutputStream)var3).close();
            this.a(var2);
            G.a(var2, this.h);
            if (this.i > 0L) {
               Files.setLastModifiedTime(this.h, FileTime.fromMillis(this.i));
            }
         } catch (Exception var11) {
            this.b = 0L;
            Files.deleteIfExists(var2);
            throw var11;
         }

         this.b = this.a;
         this.d.a();
      }
   }

   private void a(Path var1) {
      if (this.k) {
         BufferedInputStream var14 = new BufferedInputStream(Files.newInputStream(var1));

         try {
            long var15 = G.a((InputStream)var14);
            if (var15 != this.j) {
               throw new IOException(String.format("XXH64 mismatch for %s: expected %016x, got %016x", this.e, this.j, var15));
            }
         } catch (Throwable var12) {
            try {
               ((InputStream)var14).close();
            } catch (Throwable var10) {
               var12.addSuppressed(var10);
            }

            throw var12;
         }

         ((InputStream)var14).close();
      } else {
         BufferedInputStream var2 = new BufferedInputStream(Files.newInputStream(var1));

         try {
            byte[] var3 = ((InputStream)var2).readNBytes(16);
            if (var3.length < 16) {
               throw new IOException("Downloaded masbin file too short for IV: " + this.e);
            }

            byte[] var4 = n.a(this.l, this.j);
            InputStream var5 = n.a((InputStream)var2, var4, var3);

            try {
               long var6 = G.a(var5);
               if (var6 != this.j) {
                  throw new IOException(String.format("XXH64 mismatch for %s: expected %016x, got %016x", this.e, this.j, var6));
               }
            } catch (Throwable var11) {
               if (var5 != null) {
                  try {
                     var5.close();
                  } catch (Throwable var9) {
                     var11.addSuppressed(var9);
                  }
               }

               throw var11;
            }

            if (var5 != null) {
               var5.close();
            }
         } catch (Throwable var13) {
            try {
               ((InputStream)var2).close();
            } catch (Throwable var8) {
               var13.addSuppressed(var8);
            }

            throw var13;
         }

         ((InputStream)var2).close();
      }

   }

   public float b() {
      if (this.a <= 0L) {
         return this.c > 0L ? Math.min(1.0F, (float)this.b / (float)this.c) : 0.0F;
      } else {
         return Math.min(1.0F, (float)this.b / (float)this.a);
      }
   }

   public static HttpResponse a(URI var0) {
      return a(var0, false);
   }

   public static HttpResponse a(URI var0, boolean var1) {
      HttpRequest.Builder var2 = HttpRequest.newBuilder(var0).timeout(Duration.ofSeconds(20L)).setHeader("User-Agent", "ResourcePackUpdater/" + cn.zbx1425.resourcepackupdater.e.c + " +https://www.zbx1425.cn").GET();
      if (var1) {
         var2.setHeader("Accept-Encoding", "gzip");
      }

      HttpRequest var3 = var2.build();

      try {
         HttpResponse var4 = cn.zbx1425.resourcepackupdater.f.b.send(var3, BodyHandlers.ofInputStream());
         return var4;
      } catch (InterruptedException var6) {
         throw new IOException(var6);
      }
   }
}
