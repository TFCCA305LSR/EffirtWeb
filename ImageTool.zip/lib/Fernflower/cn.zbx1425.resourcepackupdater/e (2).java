package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonParser;
import java.io.IOException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_5218;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

public class e implements ModInitializer {
   public static final String a = "resourcepackupdater";
   public static final Logger b = LogManager.getLogger("ResourcePackUpdater");
   public static String c = "";
   public static final a d = new a();
   public static final JsonParser e = new JsonParser();
   public static @Nullable j f;
   private static volatile G h;

   public static G a() {
      return h;
   }

   public static void a(G var0) {
      h = var0;
   }

   public void onInitialize() {
      c = ((ModContainer)FabricLoader.getInstance().getModContainer("resourcepackupdater").get()).getMetadata().getVersion().getFriendlyString();

      try {
         d.a();
      } catch (IOException var2) {
         b.error("Failed to load config", var2);
      }

      ServerConfigurationConnectionEvents.CONFIGURE.register(h::a);
      ServerConfigurationNetworking.registerGlobalReceiver(S.a, h::a);
      ServerLifecycleEvents.SERVER_STARTING.register((ServerLifecycleEvents.ServerStarting)(var0) -> {
         f = new j(var0.method_27050(class_5218.field_24188).resolve("data").resolve("mrpu_device_mapping.json"));
         f.a();
      });
      ServerLifecycleEvents.BEFORE_SAVE.register((ServerLifecycleEvents.BeforeSave)(var0, var1, var2x) -> {
         assert f != null;

         f.b();
      });
      ServerLifecycleEvents.SERVER_STOPPED.register((ServerLifecycleEvents.ServerStopped)(var0) -> f = null);
   }
}
