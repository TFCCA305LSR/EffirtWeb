package cn.zbx1425.resourcepackupdater;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectOpenHashMap;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import net.minecraft.class_2960;
import org.apache.commons.io.IOUtils;

public class z {
   public final float a;
   public final float b;
   public final float c;
   public final float d;
   public final Char2ObjectMap e = new Char2ObjectOpenHashMap();
   private static final char k = '▯';
   public final class_2960 f;
   public final float g;
   public final float h;
   public final float i;

   public z(class_2960 var1) {
      this.f = var1;
      class_2960 var2 = new class_2960(var1.method_12836(), var1.method_12832().replace(".png", ".json"));

      JsonObject var3;
      try {
         Class var10000 = this.getClass();
         String var10001 = var2.method_12836();
         InputStream var4 = var10000.getResourceAsStream("/assets/" + var10001 + "/" + var2.method_12832());

         try {
            assert var4 != null;

            var3 = cn.zbx1425.resourcepackupdater.e.e.parse(IOUtils.toString(var4, StandardCharsets.UTF_8)).getAsJsonObject();
         } catch (Throwable var9) {
            if (var4 != null) {
               try {
                  var4.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }
            }

            throw var9;
         }

         if (var4 != null) {
            var4.close();
         }
      } catch (IOException var10) {
         throw new RuntimeException(var10);
      }

      this.a = (float)var3.get("size").getAsInt();
      this.b = (float)var3.get("width").getAsInt();
      this.c = (float)var3.get("height").getAsInt();
      JsonObject var11 = var3.getAsJsonObject("characters");

      for(Map.Entry var6 : var11.entrySet()) {
         char var7 = ((String)var6.getKey()).charAt(0);
         this.e.put(var7, new A(((JsonElement)var6.getValue()).getAsJsonObject(), this));
      }

      this.d = -((A)this.e.get('A')).h;
      A var12 = (A)this.e.get('■');
      this.g = (var12.a + var12.c) / 2.0F;
      this.h = (var12.b + var12.d) / 2.0F;
      this.i = ((A)this.e.get(' ')).i;
   }

   public A a(char var1) {
      return !this.e.containsKey(var1) ? (A)this.e.get('▯') : (A)this.e.get(var1);
   }
}
