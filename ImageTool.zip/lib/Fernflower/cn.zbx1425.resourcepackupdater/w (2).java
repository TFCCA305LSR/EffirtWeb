package cn.zbx1425.resourcepackupdater;

public class w extends RuntimeException {
   public w() {
      super("Minecraft is now stopping.");
   }
}
