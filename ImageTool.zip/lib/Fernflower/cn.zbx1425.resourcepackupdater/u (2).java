package cn.zbx1425.resourcepackupdater;

import java.io.IOException;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class u implements s {
   public float c = 500.0F;
   public float d = 400.0F;
   int e = -1;
   boolean f = false;
   private int g = -1;

   public void a() {
      int var1 = ((List)cn.zbx1425.resourcepackupdater.e.d.b.a).size() + 1;
      this.d = (float)(90 + var1 * 30 + (var1 - 1) * 10);
      if (this.e == -1) {
         this.e = ((List)cn.zbx1425.resourcepackupdater.e.d.b.a).indexOf(cn.zbx1425.resourcepackupdater.e.d.c.a);
      }

      if (this.e == -1) {
         this.e = 0;
      }

      v.b(this.c, this.d, 0.6F);
      v.a(v.a);
      s.a(this.c, this.d, -2169110);
      v.b(20.0F, 15.0F, this.c - 40.0F, 50.0F, 18.0F, "Select a Server to Download Resource Pack from\nDon't worry, you can later get back and try another one.", -14540254, false, false);

      for(int var2 = 0; var2 < var1; ++var2) {
         if (var2 == this.e) {
            v.a(30.0F, (float)(60 + var2 * 40), this.c - 60.0F, 30.0F, -10247994);
         } else {
            v.a(30.0F, (float)(60 + var2 * 40), this.c - 60.0F, 30.0F, -4140325);
         }

         String var3 = var2 == var1 - 1 ? "[Cancel Update]" : ((c)((List)cn.zbx1425.resourcepackupdater.e.d.b.a).get(var2)).a;
         v.b(45.0F, (float)(60 + var2 * 40 + 5), this.c - 90.0F, 40.0F, 20.0F, var3, -14540254, false, false);
      }

      String var4 = "W/S: Select, Enter: Confirm";
      v.b(20.0F, this.d - 20.0F, this.c - 40.0F, 16.0F, 16.0F, var4, -14540254, false, true);
      v.c();
   }

   public boolean b() {
      long var1 = class_310.method_1551().method_22683().method_4490();
      if (!class_3675.method_15987(var1, 265) && !class_3675.method_15987(var1, 87)) {
         if (!class_3675.method_15987(var1, 264) && !class_3675.method_15987(var1, 83)) {
            if (class_3675.method_15987(var1, 257) || class_3675.method_15987(var1, 32) || class_3675.method_15987(var1, 262) || this.f) {
               if (this.e == ((List)cn.zbx1425.resourcepackupdater.e.d.b.a).size()) {
                  throw new w();
               }

               cn.zbx1425.resourcepackupdater.e.d.c.a = ((List)cn.zbx1425.resourcepackupdater.e.d.b.a).get(this.e);
               cn.zbx1425.resourcepackupdater.e.d.c.b = true;

               try {
                  cn.zbx1425.resourcepackupdater.e.d.b();
               } catch (IOException var4) {
               }

               return true;
            }

            this.g = -1;
         } else if (this.g != 264 && this.g != 83) {
            this.e = Math.min(((List)cn.zbx1425.resourcepackupdater.e.d.b.a).size(), this.e + 1);
            this.g = 264;
         }
      } else if (this.g != 265 && this.g != 87) {
         this.e = Math.max(0, this.e - 1);
         this.g = 265;
      }

      return false;
   }

   public void c() {
      this.e = -1;
      this.g = -1;
      this.f = false;
   }

   public void a(String var1) {
   }

   public void b(String var1) {
   }

   public void a(float var1) {
   }

   public void a(String var1, String var2) {
   }

   public void a(Exception var1) {
   }
}
