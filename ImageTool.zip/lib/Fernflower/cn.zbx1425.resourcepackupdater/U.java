package cn.zbx1425.resourcepackupdater;

import java.util.function.Consumer;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.minecraft.class_8605;

public class U implements class_8605 {
   public static final class_8605.class_8606 a = new class_8605.class_8606("zbx_rpu:server_lock");
   public final String b;

   public U(String var1) {
      this.b = var1;
   }

   public void method_52376(Consumer var1) {
      var1.accept(ServerConfigurationNetworking.createS2CPacket(new T(this.b)));
   }

   public class_8605.class_8606 method_52375() {
      return a;
   }
}
