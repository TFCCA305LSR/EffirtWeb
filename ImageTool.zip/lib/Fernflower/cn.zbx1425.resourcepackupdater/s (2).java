package cn.zbx1425.resourcepackupdater;

public interface s {
   int a = 24;
   int b = 30;

   void a();

   boolean b();

   void c();

   void a(String var1);

   void b(String var1);

   void a(float var1);

   void a(String var1, String var2);

   void a(Exception var1);

   static void a(float var0, float var1, int var2) {
      v.a(8.0F, 8.0F, var0, var1, 1711276032);
      v.a(0.0F, 0.0F, var0, var1, var2);
   }
}
