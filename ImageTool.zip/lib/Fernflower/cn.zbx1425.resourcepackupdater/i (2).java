package cn.zbx1425.resourcepackupdater;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.licensespring.IdentityProvider;
import com.licensespring.identity.HardwareIdAlgorithm;
import com.licensespring.identity.internal.HardwareIdGenerator;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class i {
   private static volatile String a;
   private static final IdentityProvider b;

   public static String a() {
      String var0 = a;
      if (var0 != null) {
         return var0;
      } else {
         var0 = c();
         if (var0 == null) {
            var0 = f();
         }

         a = var0;
         return var0;
      }
   }

   private static boolean b() {
      return System.getProperty("os.version", "").startsWith("Android-") || System.getProperty("pojav.path.minecraft") != null;
   }

   private static String c() {
      return b() ? d() : e();
   }

   private static String d() {
      try {
         Process var0 = Runtime.getRuntime().exec(new String[]{"settings", "get", "secure", "android_id"});
         BufferedReader var2 = new BufferedReader(new InputStreamReader(var0.getInputStream()));

         String var1;
         try {
            var1 = var2.readLine();
         } catch (Throwable var6) {
            try {
               var2.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         var2.close();
         if (!var0.waitFor(5L, TimeUnit.SECONDS)) {
            var0.destroyForcibly();
            return null;
         }

         if (var1 != null) {
            var1 = var1.trim();
            if (!var1.isEmpty() && !"null".equals(var1) && !var1.startsWith("error")) {
               return "android:" + var1;
            }
         }
      } catch (Exception var7) {
         e.b.warn("Failed to get Android ID via shell", var7);
      }

      return null;
   }

   private static String e() {
      try {
         String var0 = b.getKey();
         if (var0 != null && !var0.isEmpty()) {
            return "ls:" + var0;
         }
      } catch (Exception var1) {
         e.b.warn("Failed to get hardware ID via licensespring", var1);
      }

      return null;
   }

   private static String f() {
      Path var0 = Paths.get(System.getProperty("user.home"), ".mscrc");

      try {
         if (Files.isRegularFile(var0, new LinkOption[0])) {
            String var1 = Files.readString(var0);
            JsonObject var2 = e.e.parse(var1).getAsJsonObject();
            String var3 = var2.get("id").getAsString();
            if (var3 != null && !var3.isEmpty()) {
               return "file:" + var3;
            }
         }
      } catch (Exception var5) {
         e.b.warn("Failed to read device ID file, will regenerate", var5);
      }

      String var6 = UUID.randomUUID().toString();

      try {
         JsonObject var7 = new JsonObject();
         var7.addProperty("id", var6);
         Files.writeString(var0, (new GsonBuilder()).create().toJson(var7));
      } catch (Exception var4) {
         e.b.error("Failed to write device ID file", var4);
      }

      return "file:" + var6;
   }

   static {
      b = new HardwareIdGenerator(HardwareIdAlgorithm.Default);
   }
}
