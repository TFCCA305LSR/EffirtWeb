package cn.zbx1425.resourcepackupdater;

import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_8610;
import net.minecraft.server.MinecraftServer;

public class h {
   public static void a(class_8610 var0, MinecraftServer var1) {
      if (ServerConfigurationNetworking.canSend(var0, T.a)) {
         var0.addTask(new U((String)e.d.g.a));
      } else if ((Boolean)e.d.h.a) {
         var0.method_52396(R.a((new V(e.c, "未安裝 NOT INSTALLED")).getMessage().trim()));
      }

   }

   public static void a(S var0, class_8610 var1, PacketSender var2) {
      String var3 = var0.b;
      if (!((String)e.d.i.a).isEmpty()) {
         String var4 = ((String)e.d.i.a).replace("current", e.c);
         if (!W.a(var3).b(var4)) {
            var1.method_52396(R.a((new V(e.c, var3)).getMessage().trim()));
            return;
         }
      }

      String var9 = var0.c;
      GameProfile var5 = var1.method_52404();
      String var6 = var5.getId().toString();

      try {
         if (var9 != null && !var9.isEmpty()) {
            if (e.f == null) {
               throw new IllegalStateException("Device Mapping not Loaded?");
            }

            e.f.a(var9, var6);
            e.b.debug("DeviceId: {} ({}) -> {}", var5.getName(), var6, var9);
         }

         if (FabricLoader.getInstance().isModLoaded("banhammer") && g.a(var9, var6, var1)) {
            return;
         }
      } catch (Exception var8) {
         e.b.error("Failed to process device mapping", var8);
      }

      var1.completeTask(U.a);
   }
}
