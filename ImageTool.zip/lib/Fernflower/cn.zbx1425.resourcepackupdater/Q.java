package cn.zbx1425.resourcepackupdater;

public interface Q {
   Object run();
}
