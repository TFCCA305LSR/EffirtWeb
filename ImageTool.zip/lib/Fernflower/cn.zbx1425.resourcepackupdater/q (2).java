package cn.zbx1425.resourcepackupdater;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class q implements F {
   private final u c = new u();
   private final t d = new t();
   private final r e = new r();
   private final List f;
   private s g;
   private boolean h;
   public static final class_2960 a = new class_2960("resourcepackupdater", "textures/gui/header.png");
   public static final class_2960 b = new class_2960("resourcepackupdater", "textures/gui/background.png");

   public q() {
      this.f = List.of(this.c, this.d, this.e);
      this.g = this.d;
   }

   public void a(String var1) {
      for(s var3 : this.f) {
         var3.a(var1);
      }

      cn.zbx1425.resourcepackupdater.e.b.info(var1);
      this.b(true);
   }

   public void b(String var1) {
      for(s var3 : this.f) {
         var3.b(var1);
      }

      this.b(true);
   }

   public void a(float var1) {
      for(s var3 : this.f) {
         var3.a(var1);
      }

      this.b(true);
   }

   public void a(String var1, String var2) {
      for(s var4 : this.f) {
         var4.a(var1, var2);
      }

      this.b(true);
   }

   public void a(Exception var1) {
      for(s var3 : this.f) {
         var3.a(var1);
      }

      this.g = this.e;
      this.h = true;
      cn.zbx1425.resourcepackupdater.e.b.error("Resource Update Exception", var1);
   }

   public void a() {
      this.b(true);
   }

   public boolean a(boolean var1) {
      this.h = this.h && !this.g.b();
      if (this.h) {
         this.b(var1);
      }

      return this.h;
   }

   public void b() {
      for(s var2 : this.f) {
         var2.c();
      }

      this.g = this.d;
      this.h = false;
   }

   public void c() {
      for(s var2 : this.f) {
         var2.c();
      }

      this.g = this.c;
      this.h = true;
   }

   public void d() {
      this.g = this.e;
      this.h = true;
   }

   public void b(boolean var1) {
      v.a(1.0F, 0.0F, 1.0F);
      e();
      this.g.b();
      this.g.a();
      if (var1) {
         v.d();
      }

   }

   private static void e() {
      v.g();
      v.a(b);
      class_310.method_1551().method_1531().method_4619(b).method_4527(true, false);
      float var0 = Math.max((float)v.h() / 16.0F, (float)v.i() / 9.0F);
      float var1 = 16.0F * var0;
      float var2 = 9.0F * var0;
      float var3 = ((float)v.h() - var1) / 2.0F;
      float var4 = ((float)v.i() - var2) / 2.0F;
      v.a(var3, var4, var1, var2, 0.0F, 0.0F, 1.0F, 1.0F, -1);
      v.c();
      v.a(v.a);
      v.a((float)(v.h() - 10 - 80), (float)(v.i() - 10 - 16), 80.0F, 20.0F, 16.0F, "v" + cn.zbx1425.resourcepackupdater.e.c, -256, false, true);
      v.c();
      v.a(a);
      float var5 = 512.0F;
      float var6 = var5 * 32.0F / 512.0F;
      v.a(10.0F, (float)(v.i() - 10) - var6, var5, var6, 0.0F, 0.0F, 1.0F, 1.0F, -1);
      v.c();
   }
}
