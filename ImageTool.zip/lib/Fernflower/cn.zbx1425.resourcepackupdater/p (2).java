package cn.zbx1425.resourcepackupdater;

import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public class p extends class_437 {
   private boolean b = false;
   private final HashMap c = new HashMap();

   public p() {
      super(R.a("ResourcePackUpdater Config"));
   }

   protected void method_25426() {
      super.method_25426();
      boolean var1 = true;
      int var2 = (this.field_22789 - 20) / 2;
      int var3 = var2 - 20;
      class_4185 var4 = class_4185.method_46430(R.a("Show Logs from Last Run"), (var1x) -> this.b = true).method_46434(20, 40, var3, 20).method_46431();
      class_4185 var5 = class_4185.method_46430(R.a("Update & Reload"), (var1x) -> {
         assert this.field_22787 != null;

         this.field_22787.method_1521();
      }).method_46434(10 + var2 + 10, 40, var3, 20).method_46431();
      class_4185 var6 = class_4185.method_46430(R.a("Return"), (var1x) -> {
         assert this.field_22787 != null;

         this.field_22787.method_1507((class_437)null);
      }).method_46434(10 + var2 + 10, this.field_22790 - 40, var3, 20).method_46431();
      this.method_37063(var4);
      this.method_37063(var5);
      this.method_37063(var6);
      int var7 = 90;

      for(c var9 : (List)e.d.b.a) {
         class_4185 var10 = class_4185.method_46430(R.a(var9.a), (var2x) -> {
            e.d.c.a = var9;

            try {
               e.d.b();
            } catch (IOException var4) {
               var4.printStackTrace();
            }

            this.a();
         }).method_46434(20, var7, var3, 20).method_46431();
         this.c.put(var9, var10);
         var7 += 20;
         this.method_37063(var10);
      }

      this.a();
   }

   private void a() {
      for(Map.Entry var2 : this.c.entrySet()) {
         ((class_4185)var2.getValue()).field_22763 = !((c)e.d.c.a).equals(var2.getKey());
      }

   }

   public void method_25394(@NotNull class_332 var1, int var2, int var3, float var4) {
      if (this.b) {
         v.a();

         try {
            f.a.d();
            if (!f.a.a(false)) {
               this.b = false;
            }
         } catch (w var6) {
            this.b = false;
         }

         v.b();
      } else {
         var1.method_25296(0, 0, this.field_22789, this.field_22790, -16691588, -16640982);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         var1.method_25293(q.a, 10, 10, 256, 16, 0.0F, 0.0F, 512, 32, 512, 32);
         var1.method_51433(this.field_22793, "Source Servers:", 20, 76, -1, true);
         var1.method_51433(this.field_22793, "https://www.zbx1425.cn", 20, this.field_22790 - 40, -1, true);
         super.method_25394(var1, var2, var3, var4);
      }

   }
}
