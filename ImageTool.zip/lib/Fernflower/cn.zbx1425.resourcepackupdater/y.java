package cn.zbx1425.resourcepackupdater;

import java.util.Set;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_7367;
import org.jetbrains.annotations.Nullable;

public class y implements class_3262 {
   public @Nullable class_7367 method_14410(String... var1) {
      return null;
   }

   public @Nullable class_7367 method_14405(class_3264 var1, class_2960 var2) {
      return null;
   }

   public void method_14408(class_3264 var1, String var2, String var3, class_3262.class_7664 var4) {
   }

   public Set method_14406(class_3264 var1) {
      return Set.of();
   }

   public @Nullable Object method_14407(class_3270 var1) {
      return null;
   }

   public String method_14409() {
      return "";
   }

   public void close() {
   }
}
