package cn.zbx1425.resourcepackupdater;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.jpountz.xxhash.StreamingXXHash64;
import net.jpountz.xxhash.XXHash64;
import net.jpountz.xxhash.XXHashFactory;

public class G {
   private static final byte[] d = new byte[]{77, 65, 83};
   private static final int e = 0;
   public static final int a = 48;
   private static final long f = 1577836800L;
   private static final byte g = 16;
   private static final byte h = 32;
   private static final byte i = 17;
   public UUID b;
   public long c;
   private static final String j = ":#";
   private final I k = new I("");
   private final Map l = new HashMap();
   private final Long2ObjectOpenHashMap m = new Long2ObjectOpenHashMap();
   private final Set n = new HashSet();
   private static final XXHash64 o = XXHashFactory.fastestInstance().hash64();

   public I a() {
      return this.k;
   }

   public I a(String var1) {
      long var2 = c(var1.getBytes(StandardCharsets.UTF_8));
      return (I)this.m.get(var2);
   }

   public I a(long var1) {
      return (I)this.m.get(var1);
   }

   public Map b() {
      return Collections.unmodifiableMap(this.l);
   }

   public Set c() {
      return Collections.unmodifiableSet(this.n);
   }

   public boolean b(String var1) {
      return this.n.contains(var1);
   }

   public static long b(long var0) {
      return (var0 + 1577836800L) * 1000L;
   }

   public static long c(long var0) {
      return var0 / 1000L - 1577836800L;
   }

   public static String d(long var0) {
      String var2 = String.format("%02x", (int)(var0 & 255L));
      String var3 = String.format("%016x", var0);
      return "masbin/" + var2 + "/" + var3 + ".bin";
   }

   public static Path a(Path var0, long var1) {
      String var3 = String.format("%02x", (int)(var1 & 255L));
      String var4 = String.format("%016x", var1);
      return var0.resolve("masbin").resolve(var3).resolve(var4 + ".bin");
   }

   public static void a(Path var0, Path var1) {
      try {
         Files.move(var0, var1, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (AtomicMoveNotSupportedException var3) {
         Files.move(var0, var1, StandardCopyOption.REPLACE_EXISTING);
      }

   }

   public static H a(byte[] var0) {
      if (var0.length < 48) {
         throw new IOException("masmeta.bin header too short: " + var0.length);
      } else if (var0[0] == d[0] && var0[1] == d[1] && var0[2] == d[2]) {
         if (var0[3] != 0) {
            throw new IOException("Unsupported masmeta.bin version: " + var0[3]);
         } else {
            ByteBuffer var1 = ByteBuffer.wrap(var0).order(ByteOrder.LITTLE_ENDIAN);
            ByteBuffer var2 = ByteBuffer.wrap(var0).order(ByteOrder.BIG_ENDIAN);
            var1.position(4);
            long var3 = var1.getLong();
            var2.position(16);
            long var5 = var2.getLong();
            long var7 = var2.getLong();
            UUID var9 = new UUID(var5, var7);
            var1.position(32);
            byte[] var10 = new byte[16];
            var1.get(var10);
            return new H(var3, var9, var10);
         }
      } else {
         throw new IOException("Invalid masmeta.bin magic");
      }
   }

   public static G a(Path var0) {
      byte[] var1 = Files.readAllBytes(var0);
      return b(var1);
   }

   public static G b(byte[] var0) {
      if (var0.length < 48) {
         throw new IOException("masmeta.bin too short");
      } else {
         byte[] var1 = Arrays.copyOf(var0, 48);
         H var2 = a(var1);
         byte[] var3 = Arrays.copyOfRange(var0, 48, var0.length);
         long var4 = c(var3);
         if (var4 != var2.a) {
            throw new IOException(String.format("masmeta.bin body checksum mismatch: expected %016x, got %016x", var2.a, var4));
         } else {
            byte[] var6 = cn.zbx1425.resourcepackupdater.n.a(var2.b);
            byte[] var7 = cn.zbx1425.resourcepackupdater.n.a(var3, var6, var2.c);
            G var8 = new G();
            var8.b = var2.b;
            var8.c = var2.a;
            var8.d(var7);
            return var8;
         }
      }
   }

   private void d(byte[] var1) {
      ByteBuffer var2 = ByteBuffer.wrap(var1).order(ByteOrder.LITTLE_ENDIAN);
      ArrayDeque var3 = new ArrayDeque();
      var3.push(this.k);

      while(var2.hasRemaining()) {
         byte var4 = var2.get();
         switch (var4) {
            case 16:
               int var21 = Byte.toUnsignedInt(var2.get());
               byte[] var6 = new byte[var21];
               var2.get(var6);
               String var22 = new String(var6, StandardCharsets.UTF_8);
               I var8 = new I(var22);
               boolean var23 = var22.equals(":#") && var3.size() == 1;
               if (!var23) {
                  ((I)var3.peek()).a(var8);
               }

               var3.push(var8);
               break;
            case 17:
               if (var3.size() <= 1) {
                  throw new IOException("Unexpected EndDir: stack underflow");
               }

               var3.pop();
               break;
            case 32:
               long var5 = Integer.toUnsignedLong(var2.getInt());
               long var7 = Integer.toUnsignedLong(var2.getInt());
               long var9 = var2.getLong();
               int var11 = Byte.toUnsignedInt(var2.get());
               byte[] var12 = new byte[var11];
               var2.get(var12);
               String var13 = new String(var12, StandardCharsets.UTF_8);
               I var14 = new I(var13, var5, var7, var9);
               String var15 = a((Deque)var3, (String)var13);
               boolean var16 = var3.size() == 2 && ((I)var3.peek()).a.equals(":#");
               if (var16) {
                  long var17;
                  try {
                     var17 = Long.parseUnsignedLong(var13, 16);
                  } catch (NumberFormatException var20) {
                     throw new IOException("Invalid masked file name (expected hex XXH64): " + var13);
                  }

                  this.m.put(var17, var14);
               } else {
                  ((I)var3.peek()).a(var14);
                  long var24 = c(var15.getBytes(StandardCharsets.UTF_8));
                  this.m.put(var24, var14);
               }

               this.l.put(var15, var14);
               if (var3.size() != 1) {
                  break;
               }

               if (!var13.isEmpty() && !var13.contains("/") && !var13.contains("\\") && !var13.contains("..")) {
                  this.n.add(var15);
                  break;
               }

               throw new IOException("Illegal root-level file name in masmeta.bin: " + var13);
            default:
               throw new IOException(String.format("Unknown packet type: 0x%02x", var4));
         }
      }

      if (var3.size() != 1) {
         throw new IOException("Unterminated directories in masmeta.bin");
      }
   }

   private static String a(Deque var0, String var1) {
      StringBuilder var2 = new StringBuilder();
      Iterator var3 = var0.descendingIterator();
      var3.next();

      while(var3.hasNext()) {
         var2.append(((I)var3.next()).a).append('/');
      }

      var2.append(var1);
      return var2.toString();
   }

   public static long c(byte[] var0) {
      return o.hash(var0, 0, var0.length, 0L);
   }

   public static long a(InputStream var0) {
      StreamingXXHash64 var1 = XXHashFactory.fastestInstance().newStreamingHash64(0L);
      byte[] var2 = new byte[8192];

      int var3;
      while((var3 = var0.read(var2)) != -1) {
         var1.update(var2, 0, var3);
      }

      return var1.getValue();
   }
}
