package cn.zbx1425.resourcepackupdater;

import java.util.UUID;

public final class H extends Record {
   private final long a;
   private final UUID b;
   private final byte[] c;

   public H(long var1, UUID var3, byte[] var4) {
      this.a = var1;
      this.b = var3;
      this.c = var4;
   }

   public final String toString() {
      return this.toString<invokedynamic>(this);
   }

   public final int hashCode() {
      return this.hashCode<invokedynamic>(this);
   }

   public final boolean equals(Object var1) {
      return this.equals<invokedynamic>(this, var1);
   }

   public long a() {
      return this.a;
   }

   public UUID b() {
      return this.b;
   }

   public byte[] c() {
      return this.c;
   }
}
