package cn.zbx1425.resourcepackupdater;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class I {
   public final String a;
   public final boolean b;
   public final long c;
   public final long d;
   public final long e;
   private final Map f;

   public I(String var1) {
      this.a = var1;
      this.b = true;
      this.c = 0L;
      this.d = 0L;
      this.e = 0L;
      this.f = new LinkedHashMap();
   }

   public I(String var1, long var2, long var4, long var6) {
      this.a = var1;
      this.b = false;
      this.c = var2;
      this.d = var4;
      this.e = var6;
      this.f = null;
   }

   public void a(I var1) {
      if (!this.b) {
         throw new IllegalStateException("Cannot add child to a file entry");
      } else {
         this.f.put(var1.a, var1);
      }
   }

   public I a(String var1) {
      return !this.b ? null : (I)this.f.get(var1);
   }

   public Collection a() {
      return (Collection)(!this.b ? Collections.emptyList() : this.f.values());
   }

   public I a(String... var1) {
      I var2 = this;

      for(String var6 : var1) {
         if (var2 == null || !var2.b) {
            return null;
         }

         var2 = var2.a(var6);
      }

      return var2;
   }
}
