package cn.zbx1425.resourcepackupdater;

public class V extends Exception {
   public V(String var1, String var2) {
      String var10001 = String.format("MRPU 版本不合: 請您去下載安裝 %s 版 (您現有 %s)", var1, var2);
      super("\n\n" + var10001 + "\n" + String.format("Please update your MRPU mod to the version %s (You are now using %s)", var1, var2) + "\n\n");
   }

   public V(String var1) {
      super(var1);
   }
}
