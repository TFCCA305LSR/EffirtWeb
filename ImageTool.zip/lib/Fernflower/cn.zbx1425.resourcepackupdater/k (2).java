package cn.zbx1425.resourcepackupdater;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.io.IOUtils;

public class k {
   private static final byte[] a;

   public static boolean a(FileInputStream var0) {
      var0.getChannel().position(0L);
      boolean var1 = Arrays.equals(var0.readNBytes(a.length), a);
      if (!var1) {
         var0.getChannel().position(0L);
      }

      return var1;
   }

   public static InputStream b(FileInputStream var0) {
      return (InputStream)(a(var0) ? b((InputStream)var0) : var0);
   }

   public static InputStream a(InputStream var0) {
      byte[] var1 = var0.readNBytes(a.length);
      if (var1.length != a.length) {
         return new ByteArrayInputStream(var1);
      } else {
         return (InputStream)(!Arrays.equals(var1, a) ? new SequenceInputStream(new ByteArrayInputStream(var1), var0) : b(var0));
      }
   }

   private static InputStream b(InputStream var0) {
      try {
         DataInputStream var1 = new DataInputStream(var0);

         ByteArrayInputStream var13;
         try {
            int var2 = var1.readInt();
            int var3 = var1.readInt();
            MessageDigest var5 = MessageDigest.getInstance("SHA-256");
            byte[] var6 = var1.readNBytes(32);
            SecretKeySpec var7 = new SecretKeySpec(var6, "AES");
            byte[] var8 = Arrays.copyOfRange(var5.digest(var6), 0, 16);
            IvParameterSpec var9 = new IvParameterSpec(var8);
            int var10 = var1.readInt();
            byte[] var11 = var1.readNBytes(var10);
            Cipher var12 = Cipher.getInstance("AES/CBC/PKCS5Padding");
            var12.init(2, var7, var9);
            byte[] var4 = var12.doFinal(var11);
            var13 = new ByteArrayInputStream(var4);
         } catch (Throwable var15) {
            try {
               var1.close();
            } catch (Throwable var14) {
               var15.addSuppressed(var14);
            }

            throw var15;
         }

         var1.close();
         return var13;
      } catch (Exception var16) {
         throw new IOException(var16);
      }
   }

   public static void a(byte[] var0, File var1) {
      byte[] var2;
      byte[] var3;
      try {
         MessageDigest var4 = MessageDigest.getInstance("SHA-256");
         KeyGenerator var5 = KeyGenerator.getInstance("AES");
         var5.init(256);
         var3 = var5.generateKey().getEncoded();
         SecretKeySpec var6 = new SecretKeySpec(var3, "AES");
         byte[] var7 = Arrays.copyOfRange(var4.digest(var3), 0, 16);
         IvParameterSpec var8 = new IvParameterSpec(var7);
         Cipher var9 = Cipher.getInstance("AES/CBC/PKCS5Padding");
         var9.init(1, var6, var8);
         var2 = var9.doFinal(var0);
      } catch (Exception var12) {
         throw new IOException(var12);
      }

      BufferedOutputStream var13 = new BufferedOutputStream(new FileOutputStream(var1));

      try {
         DataOutputStream var14 = new DataOutputStream(var13);
         var14.write("ZBXNMB10".getBytes(StandardCharsets.UTF_8));
         var14.writeInt(1);
         var14.writeInt(0);
         var14.write(var3);
         var14.writeInt(var2.length);
         var14.write(var2);
      } catch (Throwable var11) {
         try {
            var13.close();
         } catch (Throwable var10) {
            var11.addSuppressed(var10);
         }

         throw var11;
      }

      var13.close();
   }

   public static void a(File var0) {
      FileInputStream var2 = new FileInputStream(var0);

      label27: {
         byte[] var1;
         try {
            if (a(var2)) {
               break label27;
            }

            var1 = IOUtils.toByteArray(var2);
         } catch (Throwable var6) {
            try {
               var2.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         var2.close();
         a(var1, var0);
         return;
      }

      var2.close();
   }

   static {
      a = "ZBXNMB10".getBytes(StandardCharsets.UTF_8);
   }
}
