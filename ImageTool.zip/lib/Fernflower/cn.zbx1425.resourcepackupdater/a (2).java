package cn.zbx1425.resourcepackupdater;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

public class a {
   public final b a = new b("remoteConfigUrl", JsonElement::getAsString, JsonPrimitive::new, "");
   public final b b = new b("sources", (var0) -> {
      ArrayList var1 = new ArrayList();

      for(JsonElement var3 : var0.getAsJsonArray()) {
         var1.add(new c((JsonObject)var3));
      }

      return var1;
   }, (var0) -> {
      JsonArray var1 = new JsonArray();

      for(c var3 : var0) {
         if (!var3.c) {
            var1.add(var3.a());
         }
      }

      return var1;
   }, new ArrayList());
   public final b c = new b("selectedSource", (var0) -> new c((JsonObject)var0), c::a, () -> null);
   public final b d = new b("localPackName", JsonElement::getAsString, JsonPrimitive::new, "SyncedPack");
   public final b e = new b("disableBuiltinSources", JsonElement::getAsBoolean, JsonPrimitive::new, false);
   public final b f = new b("packBaseDirFile", (var0) -> Paths.get(var0.getAsString()), (var0) -> new JsonPrimitive(var0.toString()), () -> Paths.get(this.c()));
   public final b g = new b("serverLockKey", JsonElement::getAsString, JsonPrimitive::new, "");
   public final b h = new b("clientEnforceInstall", JsonElement::getAsBoolean, JsonPrimitive::new, false);
   public final b i = new b("clientEnforceVersion", JsonElement::getAsString, JsonPrimitive::new, "");
   public List j;
   public String k;
   public final List l;

   public a() {
      this.j = List.of(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i);
      this.k = null;
      this.l = new ArrayList();
   }

   public void a() {
      if (!Files.isRegularFile(this.d(), new LinkOption[0])) {
         this.b();
      }

      JsonObject var1;
      try {
         var1 = cn.zbx1425.resourcepackupdater.e.e.parse(Files.readString(this.d())).getAsJsonObject();
      } catch (Exception var6) {
         this.k = "Local config file is invalid, using defaults: " + var6.getMessage();
         var1 = new JsonObject();
      }

      if (FabricLoader.getInstance().getEnvironmentType() == EnvType.SERVER) {
         JsonObject var7 = new JsonObject();
         this.g.a(var1, var7);
         this.h.a(var1, var7);
         this.i.a(var1, var7);
      } else {
         this.a.a(var1, new JsonObject());
         JsonObject var2 = new JsonObject();
         if (!((String)this.a.a).isEmpty()) {
            this.l.clear();

            try {
               Q var10001 = () -> {
                  HttpRequest var1 = HttpRequest.newBuilder(new URI((String)this.a.a)).timeout(Duration.ofSeconds(10L)).setHeader("User-Agent", "ResourcePackUpdater/" + cn.zbx1425.resourcepackupdater.e.c + " +https://www.zbx1425.cn").GET().build();

                  HttpResponse var2;
                  try {
                     var2 = cn.zbx1425.resourcepackupdater.f.b.send(var1, BodyHandlers.ofString());
                  } catch (InterruptedException var4) {
                     throw new IOException(var4);
                  }

                  if (var2.statusCode() != 200) {
                     int var10002 = var2.statusCode();
                     throw new IOException("HTTP " + var10002 + " " + (String)var2.body());
                  } else {
                     return (String)var2.body();
                  }
               };
               List var10002 = this.l;
               Objects.requireNonNull(var10002);
               String var3 = (String)O.a("client_config", var10001, var10002::add);
               var2 = cn.zbx1425.resourcepackupdater.e.e.parse(var3).getAsJsonObject();
            } catch (Exception var5) {
               this.k = "Failed to fetch remote config, using local config: " + var5.getMessage();
            }
         }

         for(b var4 : this.j) {
            var4.a(var1, var2);
         }

         if (this.a.b && var2.has("remoteConfigUrl") && !var2.get("remoteConfigUrl").getAsString().equals(this.a.a)) {
            this.a.a(var2, var2);
            this.b();
         }

         if (!(Boolean)this.e.a) {
            this.e();
         }

         if (!((List)this.b.a).contains(this.c.a)) {
            this.c.a = null;
         }

         if (this.c.a == null) {
            this.c.a = new c("NOT CONFIGURED", "", true);
         }

      }
   }

   public void b() {
      JsonObject var1 = new JsonObject();
      var1.addProperty("version", 2);

      for(b var3 : this.j) {
         var3.a(var1);
      }

      Files.writeString(this.d(), (new GsonBuilder()).setPrettyPrinting().create().toJson(var1));
   }

   private void e() {
   }

   public String c() {
      String var1 = FabricLoader.getInstance().getGameDir().toString();
      return Paths.get(var1, "resourcepacks", (String)this.d.a).toAbsolutePath().normalize().toString();
   }

   public Path d() {
      return FabricLoader.getInstance().getConfigDir().resolve("resourcepackupdater.json");
   }
}
