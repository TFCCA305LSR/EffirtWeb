package cn.zbx1425.resourcepackupdater;

import java.io.OutputStream;

public class M extends OutputStream {
   private final OutputStream a;
   private long b = 0L;
   private final N c;

   public M(OutputStream var1, N var2) {
      this.a = var1;
      this.c = var2;
   }

   public void write(int var1) {
      this.a.write(var1);
      ++this.b;
      this.c.a(this.b);
   }

   public void write(byte[] var1) {
      this.a.write(var1);
      this.b += (long)var1.length;
      this.c.a(this.b);
   }

   public void write(byte[] var1, int var2, int var3) {
      this.a.write(var1, var2, var3);
      this.b += (long)var3;
      this.c.a(this.b);
   }

   public void flush() {
      this.a.flush();
   }

   public void close() {
      this.a.close();
   }
}
