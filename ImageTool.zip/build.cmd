@echo off
chcp 65001 > NUL
call gradlew.bat build
pause