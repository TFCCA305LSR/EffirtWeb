由 Open Zelix klassMaster27.0.0 和 Crk Zelix klassMaster25.0.0 倾情赞助，本资源仅供学习交流，切勿用于其他用途。

使用了Mod，用于优化美化游戏，并无特殊功能。
根据https://www.minecraft.net/zh-hans/eula：
如果您已购买 Minecraft：Java 版，您可以尽情试用或通过改动、添加工具或插件（我们统称为“Mod”）来修改它。所谓“Mod”是指您或其他人的原创作品，不包含我们有版权的代码或内容的实质部分。当您将您的 Mod 与 Minecraft：Java 版 进行组合时，我们将这种组合称为游戏的“Mod 版本”。